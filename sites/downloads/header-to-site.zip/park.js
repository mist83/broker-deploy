const parkButton = document.getElementById('park-button');
const titleEl = document.getElementById('title');
const failedUrlEl = document.getElementById('failed-url');
const targetUrlEl = document.getElementById('target-url');
const statusEl = document.getElementById('status');

const RESERVED_SITE_IDS = new Set(['_root', 'sites', 'ui', 'index']);
const MULLMANIA_BASE_DOMAIN = 'mullmania.com';

function setStatus(message, tone = '') {
  statusEl.textContent = message;
  if (tone) {
    statusEl.dataset.tone = tone;
    return;
  }
  delete statusEl.dataset.tone;
}

function parseFailedUrl() {
  const search = new URLSearchParams(window.location.search);
  return String(search.get('url') || '').trim();
}

function normalizeSiteId(rawValue) {
  return String(rawValue || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 63)
    .replace(/-+$/g, '');
}

function isMullmaniaSiteHost(hostname) {
  const host = String(hostname || '').toLowerCase();
  return host.endsWith(`.${MULLMANIA_BASE_DOMAIN}`)
    && host !== MULLMANIA_BASE_DOMAIN
    && host !== `www.${MULLMANIA_BASE_DOMAIN}`;
}

function deriveSiteId(urlString) {
  try {
    const url = new URL(urlString);
    const host = url.hostname.toLowerCase();
    if (!isMullmaniaSiteHost(host)) {
      return '';
    }

    const baseName = host.slice(0, -`.${MULLMANIA_BASE_DOMAIN}`.length);
    const siteId = normalizeSiteId(baseName.replace(/\./g, '-'));
    if (!siteId || RESERVED_SITE_IDS.has(siteId)) {
      return '';
    }
    return siteId;
  } catch {
    return '';
  }
}

function buildTargetUrl(siteId) {
  return siteId ? `https://${siteId}.mullmania.com/` : '';
}

const failedUrl = parseFailedUrl();
const siteId = deriveSiteId(failedUrl);
const targetUrl = buildTargetUrl(siteId);

if (failedUrl) {
  failedUrlEl.textContent = failedUrl;
} else {
  failedUrlEl.textContent = 'No failed URL was captured.';
}

if (siteId && targetUrl) {
  titleEl.textContent = 'This site did not resolve.';
  targetUrlEl.textContent = `Park as ${targetUrl}`;
} else {
  titleEl.textContent = 'This page is not parkable.';
  targetUrlEl.textContent = 'Parking is only offered for unclaimed Mullmania subdomains.';
  parkButton.disabled = true;
}

parkButton.addEventListener('click', async () => {
  parkButton.disabled = true;
  setStatus('Parking…');

  try {
    const result = await chrome.runtime.sendMessage({
      type: 'park-site',
      payload: {
        failedUrl,
      },
    });

    if (result?.error) {
      throw new Error(result.error);
    }

    const nextUrl = String(result?.url || targetUrl).trim();
    if (!nextUrl) {
      throw new Error('Parking succeeded, but no destination URL was returned.');
    }

    setStatus(result.existed ? 'Site already existed. Opening it now…' : 'Parked. Opening it now…', 'good');
    window.location.replace(nextUrl);
  } catch (error) {
    setStatus(error.message || String(error), 'bad');
    parkButton.disabled = false;
  }
});
