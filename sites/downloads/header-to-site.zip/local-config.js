export const SITE_KEY_HEADER = 'x-site-key';
export const SITE_KEY = '';
export const SITES_API_BASE = 'https://btuarc3jsqogre3oi3spieaoqm0ceqvu.lambda-url.us-west-2.on.aws';
