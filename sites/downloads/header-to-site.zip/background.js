import { SITE_KEY, SITE_KEY_HEADER, SITES_API_BASE } from './local-config.js';

const RULE_ID = 1;
const PARK_PAGE_PATH = 'park.html';
const ACTION_TITLE = 'Mullmania Chrome Plugin';
const RESERVED_SITE_IDS = new Set(['_root', 'sites', 'ui', 'index']);
const MULLMANIA_BASE_DOMAIN = 'mullmania.com';
const TARGET_RESOURCE_TYPES = [
  'main_frame',
  'sub_frame',
  'stylesheet',
  'script',
  'image',
  'font',
  'xmlhttprequest',
  'ping',
  'csp_report',
  'media',
  'websocket',
  'webtransport',
  'webbundle',
  'other',
];
const STORAGE_KEYS = {
  enabled: 'enabled',
  locked: 'locked',
  profile: 'profile',
};
const DEFAULTS = {
  enabled: true,
  locked: false,
  profile: {
    headerName: SITE_KEY_HEADER,
    headerValue: SITE_KEY,
    domains: ['mullmania.com', 'ipzom.com'],
  },
};
const BADGE_COLORS = {
  on: '#16a34a',
  off: '#6b7280',
  error: '#dc2626',
};
const CATALOG_CACHE_TTL_MS = 60_000;
let catalogCache = {
  expiresAt: 0,
  siteIds: null,
};

function normalizeEnabled(value) {
  return value !== false;
}

function normalizeSiteKey(value) {
  return String(value || '').trim();
}

function normalizeHeaderName(value) {
  return String(value || '').trim().toLowerCase() || 'x-site-key';
}

function normalizeHeaderValue(value) {
  return String(value || '').trim();
}

function normalizeDomain(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/\/.*$/, '')
    .replace(/^\*\./, '')
    .replace(/:\d+$/, '')
    .replace(/^\.+|\.+$/g, '');
}

function normalizeDomains(value) {
  const rawItems = Array.isArray(value)
    ? value
    : String(value || '').split(/[\n,]+/);
  return Array.from(new Set(rawItems.map(normalizeDomain).filter(Boolean)));
}

function normalizeApiBase(value) {
  return String(value || '').trim().replace(/\/+$/, '');
}

function normalizeProfile(value = {}) {
  return {
    headerName: normalizeHeaderName(value.headerName || DEFAULTS.profile.headerName),
    headerValue: normalizeHeaderValue(value.headerValue || DEFAULTS.profile.headerValue),
    domains: normalizeDomains(value.domains || DEFAULTS.profile.domains),
  };
}

function isConfiguredProfile(profile) {
  return Boolean(profile.headerName && profile.headerValue && profile.domains.length);
}

function buildRule(profile) {
  return {
    id: RULE_ID,
    priority: 1,
    action: {
      type: 'modifyHeaders',
      requestHeaders: [
        {
          header: normalizeHeaderName(profile.headerName),
          operation: 'set',
          value: normalizeHeaderValue(profile.headerValue),
        },
      ],
    },
    condition: {
      requestDomains: normalizeDomains(profile.domains),
      resourceTypes: TARGET_RESOURCE_TYPES,
    },
  };
}

async function getState() {
  const stored = await chrome.storage.local.get(DEFAULTS);
  const enabled = normalizeEnabled(stored.enabled);
  const locked = stored.locked === true;
  const profile = normalizeProfile(stored.profile);
  const configured = isConfiguredProfile(profile);
  return {
    enabled,
    locked,
    ...profile,
    configured,
    active: enabled && configured,
  };
}

async function ensureDefaults() {
  const stored = await chrome.storage.local.get(DEFAULTS);
  if (typeof stored.enabled !== 'boolean') {
    await chrome.storage.local.set({ enabled: DEFAULTS.enabled });
  }
  if (typeof stored.locked !== 'boolean') {
    await chrome.storage.local.set({ locked: DEFAULTS.locked });
  }
  await chrome.storage.local.set({ profile: normalizeProfile(stored.profile || DEFAULTS.profile) });
}

async function updateActionPresentation(state = null) {
  const nextState = state || await getState();
  const badgeText = nextState.configured
    ? (nextState.active ? 'ON' : 'OFF')
    : 'ERR';
  const badgeColor = nextState.configured
    ? (nextState.active ? BADGE_COLORS.on : BADGE_COLORS.off)
    : BADGE_COLORS.error;

  await chrome.action.setBadgeText({ text: badgeText });
  await chrome.action.setBadgeBackgroundColor({ color: badgeColor });
  await chrome.action.setTitle({ title: ACTION_TITLE });
}

async function applyRules() {
  const state = await getState();
  const update = {
    removeRuleIds: [RULE_ID],
  };

  if (state.active) {
    update.addRules = [buildRule(state)];
  }

  await chrome.declarativeNetRequest.updateDynamicRules(update);
  await updateActionPresentation(state);
  return state;
}

async function initialize() {
  await ensureDefaults();
  await applyRules();
}

async function setEnabled(enabled) {
  await chrome.storage.local.set({ enabled: normalizeEnabled(enabled) });
  return applyRules();
}

async function setLocked(locked) {
  await chrome.storage.local.set({ locked: locked === true });
  return applyRules();
}

async function setProfile(profile) {
  await chrome.storage.local.set({ profile: normalizeProfile(profile) });
  return applyRules();
}

async function maybeReloadTab(tab) {
  if (!tab?.id || !/^https?:/i.test(String(tab.url || ''))) {
    return;
  }
  await chrome.tabs.reload(tab.id);
}

function isDnsResolutionError(error) {
  return String(error || '').includes('ERR_NAME_NOT_RESOLVED');
}

function parseFailedUrl(urlString) {
  try {
    const url = new URL(urlString);
    if (!['http:', 'https:'].includes(url.protocol)) {
      return null;
    }
    return url;
  } catch {
    return null;
  }
}

function isMullmaniaSiteHost(hostname) {
  const host = String(hostname || '').toLowerCase();
  return host.endsWith(`.${MULLMANIA_BASE_DOMAIN}`)
    && host !== MULLMANIA_BASE_DOMAIN
    && host !== `www.${MULLMANIA_BASE_DOMAIN}`;
}

function isParkableRootDocument(url) {
  if (!url) {
    return false;
  }

  const pathname = String(url.pathname || '');
  return pathname === '/' || pathname === '/index.html';
}

function normalizeSiteId(rawValue) {
  return String(rawValue || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 63)
    .replace(/-+$/g, '');
}

function deriveSiteIdFromUrl(urlString) {
  const parsed = parseFailedUrl(urlString);
  if (!parsed) {
    return '';
  }

  const host = parsed.hostname.toLowerCase();
  if (!isMullmaniaSiteHost(host)) {
    return '';
  }

  const baseName = host.slice(0, -`.${MULLMANIA_BASE_DOMAIN}`.length);
  const siteId = normalizeSiteId(baseName.replace(/\./g, '-'));

  if (!siteId || RESERVED_SITE_IDS.has(siteId)) {
    return '';
  }

  return siteId;
}

function buildParkPageUrl(failedUrl, error) {
  const pageUrl = new URL(chrome.runtime.getURL(PARK_PAGE_PATH));
  pageUrl.searchParams.set('url', failedUrl);
  pageUrl.searchParams.set('error', error || '');
  return pageUrl.toString();
}

async function maybeShowParkPage(details) {
  if (!details || details.frameId !== 0 || details.tabId < 0) {
    return;
  }

  if (!isDnsResolutionError(details.error)) {
    return;
  }

  if (!parseFailedUrl(details.url)) {
    return;
  }

  const state = await getState();
  if (!state.active) {
    return;
  }

  const siteId = deriveSiteIdFromUrl(details.url);
  if (!siteId) {
    return;
  }

  let exists = false;
  try {
    exists = await siteExistsForUrl(details.url);
  } catch (error) {
    console.warn('Failed to confirm Mullmania site absence before parking.', error);
    return;
  }

  if (exists) {
    return;
  }

  await chrome.tabs.update(details.tabId, {
    url: buildParkPageUrl(details.url, details.error),
  });
}

async function resolveSitesApiBaseUrl() {
  const apiBaseUrl = normalizeApiBase(SITES_API_BASE);
  return apiBaseUrl || 'https://btuarc3jsqogre3oi3spieaoqm0ceqvu.lambda-url.us-west-2.on.aws';
}

async function loadCatalogSiteIds(forceRefresh = false) {
  const now = Date.now();
  if (!forceRefresh && catalogCache.siteIds instanceof Set && catalogCache.expiresAt > now) {
    return catalogCache.siteIds;
  }

  const apiBaseUrl = await resolveSitesApiBaseUrl();
  const response = await fetch(`${apiBaseUrl}/api/catalog`, {
    headers: {
      accept: 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(`Catalog lookup failed with ${response.status}.`);
  }

  const payload = await response.json();
  const siteIds = new Set(
    Array.isArray(payload?.sites)
      ? payload.sites
        .map((entry) => normalizeSiteId(entry?.siteId))
        .filter(Boolean)
      : [],
  );

  catalogCache = {
    expiresAt: now + CATALOG_CACHE_TTL_MS,
    siteIds,
  };
  return siteIds;
}

async function siteExistsForUrl(urlString) {
  const siteId = deriveSiteIdFromUrl(urlString);
  if (!siteId) {
    return false;
  }

  const siteIds = await loadCatalogSiteIds();
  return siteIds.has(siteId);
}

async function maybeShowParkPageForNotFound(details) {
  if (!details || details.tabId < 0 || details.type !== 'main_frame') {
    return;
  }

  if (details.statusCode !== 404) {
    return;
  }

  const parsed = parseFailedUrl(details.url);
  if (!parsed || !isParkableRootDocument(parsed)) {
    return;
  }

  const state = await getState();
  if (!state.active) {
    return;
  }

  const siteId = deriveSiteIdFromUrl(details.url);
  if (!siteId) {
    return;
  }

  let exists = false;
  try {
    exists = await siteExistsForUrl(details.url);
  } catch (error) {
    console.warn('Failed to confirm Mullmania site existence before parking.', error);
    return;
  }

  if (exists) {
    return;
  }

  await chrome.tabs.update(details.tabId, {
    url: buildParkPageUrl(details.url, `HTTP_${details.statusCode}`),
  });
}

async function parkSite({ failedUrl }) {
  const siteId = deriveSiteIdFromUrl(failedUrl);
  if (!siteId) {
    throw new Error('Could not derive a valid Mullmania site id from that failed URL.');
  }

  const state = await getState();
  const trimmedSiteKey = normalizeSiteKey(state.headerValue);
  if (!trimmedSiteKey) {
    throw new Error('The Mullmania site header is not configured in this extension.');
  }

  const apiBaseUrl = await resolveSitesApiBaseUrl();
  const targetUrl = `https://${siteId}.mullmania.com/`;
  const response = await fetch(`${apiBaseUrl}/api/extension/park/${encodeURIComponent(siteId)}`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      [normalizeHeaderName(state.headerName)]: trimmedSiteKey,
    },
    body: JSON.stringify({}),
  });

  let payload = null;
  try {
    payload = await response.json();
  } catch {
  }

  if (!response.ok) {
    throw new Error(String(payload?.error || `Parking failed with ${response.status}.`).trim());
  }

  if (catalogCache.siteIds instanceof Set) {
    catalogCache.siteIds.add(siteId);
    catalogCache.expiresAt = Date.now() + CATALOG_CACHE_TTL_MS;
  }

  return {
    siteId,
    url: String(payload?.url || targetUrl).trim() || targetUrl,
    existed: payload?.existed === true,
  };
}

chrome.runtime.onInstalled.addListener(() => {
  void initialize();
});

chrome.runtime.onStartup.addListener(() => {
  void applyRules();
});

chrome.webNavigation.onErrorOccurred.addListener((details) => {
  void maybeShowParkPage(details);
});

if (chrome.declarativeNetRequest?.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
    if (info?.rule?.ruleId !== RULE_ID) {
      return;
    }
    console.debug('Matched Mullmania header rule.', {
      request: info.request,
      rule: info.rule,
    });
  });
}

chrome.webRequest.onCompleted.addListener((details) => {
  void maybeShowParkPageForNotFound(details)
    .catch((error) => console.error('Failed to handle Mullmania not-found parking flow.', error));
}, {
  urls: ['*://*.mullmania.com/*'],
  types: ['main_frame'],
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local') {
    return;
  }

  const trackedKeys = new Set(Object.values(STORAGE_KEYS));
  const shouldRefresh = Object.keys(changes).some((key) => trackedKeys.has(key));
  if (shouldRefresh) {
    void applyRules();
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || typeof message.type !== 'string') {
    return false;
  }

  if (message.type === 'park-site') {
    parkSite(message.payload || {})
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ error: error.message || String(error) }));
    return true;
  }

  if (message.type === 'get-status') {
    getState()
      .then((state) => sendResponse(state))
      .catch((error) => sendResponse({ error: error.message || String(error) }));
    return true;
  }

  if (message.type === 'set-enabled') {
    setEnabled(message.enabled)
      .then((state) => sendResponse(state))
      .catch((error) => sendResponse({ error: error.message || String(error) }));
    return true;
  }

  if (message.type === 'set-locked') {
    setLocked(message.locked)
      .then((state) => sendResponse(state))
      .catch((error) => sendResponse({ error: error.message || String(error) }));
    return true;
  }

  if (message.type === 'set-profile') {
    setProfile(message.profile || {})
      .then((state) => sendResponse(state))
      .catch((error) => sendResponse({ error: error.message || String(error) }));
    return true;
  }

  return false;
});
