const DEFAULTS = {
  enabled: true,
  locked: false,
  headerName: 'x-site-key',
  headerValue: '',
  domains: ['mullmania.com', 'ipzom.com'],
};

const form = document.getElementById('settings-form');
const enabledInput = document.getElementById('enabled');
const lockedInput = document.getElementById('locked');
const headerNameInput = document.getElementById('header-name');
const headerValueInput = document.getElementById('header-value');
const domainsInput = document.getElementById('domains');
const saveProfileButton = document.getElementById('save-profile');
const clearButton = document.getElementById('clear-profile');
const statusEl = document.getElementById('status');

function setStatus(message, tone = '') {
  statusEl.textContent = message;
  if (tone) {
    statusEl.dataset.tone = tone;
    return;
  }
  delete statusEl.dataset.tone;
}

function applyStatus(state) {
  if (state.error) {
    setStatus(state.error, 'bad');
    return;
  }

  if (state.active) {
    setStatus(
      state.locked
        ? `Active and locked on ${state.domains.join(', ')} using ${state.headerName}.`
        : `Active on ${state.domains.join(', ')} using ${state.headerName}.`,
      'good',
    );
    return;
  }

  if (state.enabled) {
    setStatus('Enabled, but the header name, value, or sites are missing.', 'bad');
    return;
  }

  setStatus('Disabled. Requests are not being modified.');
}

async function readStatus() {
  return chrome.runtime.sendMessage({ type: 'get-status' });
}

function syncLockState(state) {
  const locked = Boolean(state.locked);
  enabledInput.disabled = locked;
  headerNameInput.disabled = locked;
  headerValueInput.disabled = locked;
  domainsInput.disabled = locked;
  saveProfileButton.disabled = locked;
  clearButton.disabled = locked;
}

function applyState(state) {
  enabledInput.checked = state.enabled ?? DEFAULTS.enabled;
  lockedInput.checked = state.locked ?? DEFAULTS.locked;
  headerNameInput.value = state.headerName || DEFAULTS.headerName;
  headerValueInput.value = state.headerValue || DEFAULTS.headerValue;
  domainsInput.value = Array.isArray(state.domains) && state.domains.length
    ? state.domains.join('\n')
    : DEFAULTS.domains.join('\n');
  syncLockState(state);
  applyStatus(state);
}

async function loadForm() {
  const state = await readStatus();
  applyState(state);
}

async function setEnabled(enabled) {
  const state = await chrome.runtime.sendMessage({
    type: 'set-enabled',
    enabled,
  });
  if (state?.error) {
    await loadForm();
    return;
  }
  applyState(state);
}

async function setLocked(locked) {
  const state = await chrome.runtime.sendMessage({
    type: 'set-locked',
    locked,
  });
  if (state?.error) {
    await loadForm();
    return;
  }
  applyState(state);
}

async function setProfile(profile) {
  const state = await chrome.runtime.sendMessage({
    type: 'set-profile',
    profile,
  });
  if (state?.error) {
    await loadForm();
    return;
  }
  applyState(state);
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  setStatus('Saving…');
  await setProfile({
    headerName: headerNameInput.value,
    headerValue: headerValueInput.value,
    domains: domainsInput.value,
  });
});

clearButton.addEventListener('click', async () => {
  headerValueInput.value = '';
  setStatus('Clearing…');
  await setProfile({
    headerName: headerNameInput.value,
    headerValue: '',
    domains: domainsInput.value,
  });
});

enabledInput.addEventListener('change', async () => {
  setStatus('Saving…');
  await setEnabled(enabledInput.checked);
});

lockedInput.addEventListener('change', async () => {
  setStatus(lockedInput.checked ? 'Locking…' : 'Unlocking…');
  await setLocked(lockedInput.checked);
});

loadForm().catch((error) => {
  setStatus(error.message || String(error), 'bad');
});
