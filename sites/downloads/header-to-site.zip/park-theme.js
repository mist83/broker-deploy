(function () {
  function baseFromFailedUrl() {
    try {
      const failedUrl = new URLSearchParams(window.location.search).get('url');
      const host = new URL(failedUrl || '').hostname;
      const parts = host.split('.').filter(Boolean);
      return parts.length >= 2 ? parts.slice(-2).join('.') : '';
    } catch {
      return '';
    }
  }

  const explicit = window.__CANON_BASE_DOMAIN__;
  const fallback = document.documentElement.getAttribute('data-base-domain');
  const baseDomain = String(explicit || baseFromFailedUrl() || fallback || 'mullmania.com').trim();
  const cssLink = document.getElementById('ui-css');

  if (!cssLink || !baseDomain) {
    return;
  }

  cssLink.href = `https://ui.${baseDomain}/active/style.css`;
})();
