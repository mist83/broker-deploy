#!/bin/zsh
set -euo pipefail

INSTALL_DIR="$HOME/Applications/Gitter"
LAUNCH_AGENTS_DIR="$HOME/Library/LaunchAgents"
DAEMON_PLIST="$LAUNCH_AGENTS_DIR/com.mist83.gitterd.plist"
MENU_PLIST="$LAUNCH_AGENTS_DIR/com.mist83.gitter-menu.plist"

launchctl bootout "gui/$(id -u)" "$DAEMON_PLIST" >/dev/null 2>&1 || true
launchctl bootout "gui/$(id -u)" "$MENU_PLIST" >/dev/null 2>&1 || true
rm -f "$DAEMON_PLIST" "$MENU_PLIST"
rm -rf "$INSTALL_DIR"

echo "Removed Gitter from $INSTALL_DIR"
