#!/bin/zsh
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/Applications/Gitter"
RUNTIME_DIR="$INSTALL_DIR/gitter"
APP_DIR="$INSTALL_DIR/Gitter Menu.app"
CONFIG_PATH="$INSTALL_DIR/gitter-app.json"
LAUNCH_AGENTS_DIR="$HOME/Library/LaunchAgents"
LOG_DIR="$HOME/Library/Logs/Gitter"
DAEMON_PLIST="$LAUNCH_AGENTS_DIR/com.mist83.gitterd.plist"
MENU_PLIST="$LAUNCH_AGENTS_DIR/com.mist83.gitter-menu.plist"
PRESERVED_CONFIG=""

if [[ -f "$RUNTIME_DIR/gitter.local.json" ]]; then
  PRESERVED_CONFIG="$(mktemp "${TMPDIR:-/tmp}/gitter.local.XXXXXX.json")"
  cp "$RUNTIME_DIR/gitter.local.json" "$PRESERVED_CONFIG"
fi

mkdir -p "$HOME/Applications" "$LAUNCH_AGENTS_DIR" "$LOG_DIR"
rm -rf "$INSTALL_DIR"
mkdir -p "$INSTALL_DIR"

/usr/bin/ditto "$BUNDLE_DIR/Gitter Menu.app" "$APP_DIR"
/usr/bin/ditto "$BUNDLE_DIR/gitter" "$RUNTIME_DIR"

if [[ -n "$PRESERVED_CONFIG" ]]; then
  mv "$PRESERVED_CONFIG" "$RUNTIME_DIR/gitter.local.json"
fi

cat > "$CONFIG_PATH" <<JSON
{
  "repo_root": "$RUNTIME_DIR"
}
JSON

/usr/bin/python3 -m pip install --user -r "$RUNTIME_DIR/requirements.txt"

cat > "$DAEMON_PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.mist83.gitterd</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/zsh</string>
    <string>$RUNTIME_DIR/run-gitterd.sh</string>
  </array>
  <key>WorkingDirectory</key>
  <string>$RUNTIME_DIR</string>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>ProcessType</key>
  <string>Background</string>
  <key>StandardOutPath</key>
  <string>$LOG_DIR/gitterd.launchd.log</string>
  <key>StandardErrorPath</key>
  <string>$LOG_DIR/gitterd.launchd.err.log</string>
</dict>
</plist>
PLIST

cat > "$MENU_PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.mist83.gitter-menu</string>
  <key>ProgramArguments</key>
  <array>
    <string>$APP_DIR/Contents/MacOS/applet</string>
  </array>
  <key>WorkingDirectory</key>
  <string>$INSTALL_DIR</string>
  <key>RunAtLoad</key>
  <true/>
  <key>LimitLoadToSessionType</key>
  <array>
    <string>Aqua</string>
  </array>
  <key>StandardOutPath</key>
  <string>$LOG_DIR/menu-bar.log</string>
  <key>StandardErrorPath</key>
  <string>$LOG_DIR/menu-bar.error.log</string>
</dict>
</plist>
PLIST

launchctl bootout "gui/$(id -u)" "$DAEMON_PLIST" >/dev/null 2>&1 || true
launchctl bootstrap "gui/$(id -u)" "$DAEMON_PLIST"
launchctl kickstart -k "gui/$(id -u)/com.mist83.gitterd"

launchctl bootout "gui/$(id -u)" "$MENU_PLIST" >/dev/null 2>&1 || true
launchctl bootstrap "gui/$(id -u)" "$MENU_PLIST"
launchctl enable "gui/$(id -u)/com.mist83.gitter-menu"
launchctl kickstart -k "gui/$(id -u)/com.mist83.gitter-menu"

/usr/bin/open "$APP_DIR" >/dev/null 2>&1 || true

echo "Installed Gitter to $INSTALL_DIR"
echo "The daemon is running now and will restart at login."
echo "Dashboard: http://127.0.0.1:9477/"
