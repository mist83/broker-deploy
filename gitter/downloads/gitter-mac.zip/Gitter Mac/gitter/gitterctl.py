#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import json
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

from gitterconfig import config_payload, save_payload
from gitterlib import (
    CONTROL_FILE,
    LOG_DIR,
    REPORT_FILE,
    ROOT_DIR,
    STATUS_FILE,
    dashboard_url,
    load_control,
    load_json,
    save_control,
)

WEB_DASHBOARD_URL = "http://127.0.0.1:9481/"


def run_open(args: list[str]) -> int:
    return subprocess.run(args, check=False).returncode


def open_in_finder(path: Path, reveal: bool = False) -> int:
    if reveal:
        return run_open(["open", "-R", str(path)])
    return run_open(["open", str(path)])


def open_in_terminal(path: Path) -> int:
    return run_open(["open", "-a", "Terminal", str(path)])


def open_in_textedit(path: Path) -> int:
    return run_open(["open", "-a", "TextEdit", str(path)])


def url_is_reachable(url: str) -> bool:
    request = urllib.request.Request(url, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=0.75) as response:
            return int(getattr(response, "status", 200) or 200) < 500
    except (urllib.error.URLError, TimeoutError, ValueError):
        return False


def open_dashboard() -> int:
    if url_is_reachable(WEB_DASHBOARD_URL):
        return run_open(["open", WEB_DASHBOARD_URL])

    status = load_json(STATUS_FILE, {})
    if isinstance(status, dict) and status.get("dashboard_url"):
        return run_open(["open", str(status["dashboard_url"])])
    return run_open(["open", dashboard_url()])


def print_status() -> int:
    status = load_json(STATUS_FILE, {})
    print(json.dumps(status, indent=2, sort_keys=False))
    return 0


def print_audit() -> int:
    status = load_json(STATUS_FILE, {})
    repos = status.get("repos") if isinstance(status, dict) and isinstance(status.get("repos"), list) else []
    summary = {
        "tracked_repo_count": int(status.get("tracked_repo_count", 0) or 0) if isinstance(status, dict) else 0,
        "problem_repo_count": int(status.get("problem_repo_count", 0) or 0) if isinstance(status, dict) else 0,
        "dirty_repos": [
            repo.get("name")
            for repo in repos
            if isinstance(repo, dict) and bool(repo.get("dirty"))
        ],
        "off_mainline_repos": [
            repo.get("name")
            for repo in repos
            if isinstance(repo, dict) and bool(repo.get("off_mainline"))
        ],
        "repos_with_real_untracked": [
            repo.get("name")
            for repo in repos
            if isinstance(repo, dict) and int(repo.get("untracked_change_count", 0) or 0) > 0
        ],
        "repos_with_generated_untracked": [
            repo.get("name")
            for repo in repos
            if isinstance(repo, dict) and int(repo.get("generated_untracked_count", 0) or 0) > 0
        ],
    }
    print(json.dumps(summary, indent=2, sort_keys=False))
    return 0


def print_config_json() -> int:
    print(json.dumps(config_payload(), indent=2, sort_keys=False))
    return 0


def save_config_json(encoded_payload: str) -> int:
    raw_json = base64.b64decode(encoded_payload.encode("ascii")).decode("utf-8")
    payload = json.loads(raw_json)
    if not isinstance(payload, dict):
        raise ValueError("Config payload must decode to an object.")

    print(json.dumps(save_payload(payload), indent=2, sort_keys=False))
    return 0


def update_control(**changes: object) -> int:
    control = load_control()
    control.update(changes)
    save_control(control)
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Control the local gitter daemon.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("status", help="Print the current daemon status JSON.")
    subparsers.add_parser("audit", help="Print a hygiene summary from the current daemon status.")
    subparsers.add_parser("pause", help="Pause future sync cycles.")
    subparsers.add_parser("resume", help="Resume sync cycles.")
    subparsers.add_parser("run-now", help="Request an immediate full sync cycle, including remote fetch/pull work.")
    subparsers.add_parser("sync-now", help="Alias for run-now.")
    subparsers.add_parser("config-json", help="Print the current config payload as JSON.")
    save_config_parser = subparsers.add_parser("save-config-json", help="Save config payload from a base64-encoded JSON argument.")
    save_config_parser.add_argument("payload_base64", help="Base64-encoded config JSON object.")
    subparsers.add_parser("open-logs", help="Open the gitter log directory.")
    subparsers.add_parser("open-dashboard", help="Open the local ops cockpit dashboard.")
    subparsers.add_parser("open-status", help="Open the live status JSON in TextEdit.")
    subparsers.add_parser("open-report", help="Open the current problems report in TextEdit.")
    subparsers.add_parser("open-root", help="Open the gitter project root in Finder.")

    open_repo = subparsers.add_parser("open-repo", help="Open a tracked repo path.")
    open_repo.add_argument("path", help="Absolute path to the repo.")
    open_repo.add_argument("--terminal", action="store_true", help="Open the repo in Terminal instead of Finder.")
    open_repo.add_argument("--reveal", action="store_true", help="Reveal the repo path in Finder.")

    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if args.command == "status":
        return print_status()

    if args.command == "audit":
        return print_audit()

    if args.command == "pause":
        return update_control(paused=True)

    if args.command == "resume":
        return update_control(paused=False)

    if args.command == "run-now" or args.command == "sync-now":
        return update_control(run_now=True, paused=False, force_pull=True)

    if args.command == "config-json":
        return print_config_json()

    if args.command == "save-config-json":
        return save_config_json(args.payload_base64)

    if args.command == "open-logs":
        return open_in_finder(LOG_DIR)

    if args.command == "open-dashboard":
        return open_dashboard()

    if args.command == "open-status":
        return open_in_textedit(STATUS_FILE)

    if args.command == "open-report":
        return open_in_textedit(REPORT_FILE)

    if args.command == "open-root":
        return open_in_finder(ROOT_DIR)

    if args.command == "open-repo":
        target = Path(args.path).expanduser()
        if args.terminal:
            return open_in_terminal(target)
        return open_in_finder(target, reveal=args.reveal)

    return 1


if __name__ == "__main__":
    sys.exit(main())
