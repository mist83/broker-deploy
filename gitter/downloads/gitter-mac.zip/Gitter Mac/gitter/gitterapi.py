from __future__ import annotations

import json
import mimetypes
import subprocess
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from typing import Any, Callable
from urllib.parse import parse_qs, urlparse

from gitterai import AIConfigError, AIExplanationError, collect_git_diagnostics, explain_repo
from gitterlib import (
    CONTROL_PLANE_HOST,
    CONTROL_PLANE_PORT,
    CONTROL_FILE,
    ROOT_DIR,
    STATUS_FILE,
    control_plane_origin,
    dashboard_url,
    load_control,
    load_json,
    save_control,
)
from gitterops import load_activity_events

MAX_JSON_BODY_BYTES = 64 * 1024


def run_open(args: list[str]) -> int:
    return subprocess.run(args, check=False).returncode


def open_in_finder(path: Path, reveal: bool = False) -> int:
    if reveal:
        return run_open(["open", "-R", str(path)])
    return run_open(["open", str(path)])


def open_in_terminal(path: Path) -> int:
    return run_open(["open", "-a", "Terminal", str(path)])


def _parse_iso(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None


def _format_relative(value: Any) -> str:
    dt = _parse_iso(value)
    if dt is None:
        return "never"
    now = datetime.now(timezone.utc if dt.tzinfo else None)
    delta = max(0, (now - dt).total_seconds())
    if delta < 15:
        return "just now"
    if delta < 60:
        return f"{int(delta)}s ago"
    if delta < 3600:
        return f"{int(delta // 60)}m ago"
    if delta < 86400:
        return f"{int(delta // 3600)}h ago"
    return f"{int(delta // 86400)}d ago"


def _cycle_status(status: dict[str, Any]) -> str:
    if not status:
        return "status unavailable"
    if status.get("paused"):
        return "paused"
    if status.get("scan_in_progress"):
        current = str(status.get("current_repo") or "")
        label = current.rsplit("/", 1)[-1] if current else ""
        return f"running · {label}" if label else "running"

    interval = int(status.get("interval_seconds") or 300)
    last_dt = _parse_iso(status.get("last_successful_sync_at"))
    if last_dt is None:
        return "next run soon"
    now = datetime.now(timezone.utc if last_dt.tzinfo else None)
    remaining = int((last_dt.timestamp() + interval) - now.timestamp())
    if remaining <= 0:
        return "next run imminent"
    rounded = max(5, (remaining // 5) * 5)
    return f"next run in {rounded}s"


def _protection_tone(state: str) -> str:
    if state in {"blocked", "diverged"}:
        return "danger"
    if state in {"dirty", "behind", "ahead", "new", "off-mainline"}:
        return "warning"
    return "success"


def _severity_tone(severity: str) -> str:
    if severity == "error":
        return "danger"
    if severity == "warning":
        return "warning"
    return "info"


def _stat(label: str, value: str, caption: str = "", tone: str | None = None, badge_label: str | None = None) -> dict[str, Any]:
    node: dict[str, Any] = {"component": "stat", "label": label, "value": value}
    if caption:
        node["caption"] = caption
    if tone:
        node["badge"] = {"label": badge_label or tone.title(), "tone": tone}
    return node


def build_contract(status: dict[str, Any], problems: list[dict[str, Any]], activity: list[dict[str, Any]]) -> dict[str, Any]:
    tracked = int(status.get("tracked_repo_count") or 0)
    problem_count = int(status.get("problem_repo_count") or 0)
    repos = status.get("repos") or []
    top_attention = status.get("top_attention_repos") or []
    dirty_count = sum(1 for repo in repos if isinstance(repo, dict) and repo.get("dirty"))
    off_mainline_count = sum(1 for repo in repos if isinstance(repo, dict) and repo.get("off_mainline"))

    summary_stats = {
        "component": "grid",
        "columns": 4,
        "children": [
            _stat(
                "Tracked",
                str(tracked),
                caption=_cycle_status(status),
                tone="success" if not status.get("paused") else "warning",
                badge_label="Live" if status.get("scan_in_progress") else ("Paused" if status.get("paused") else "Idle"),
            ),
            _stat(
                "Problems",
                str(problem_count),
                caption="repos flagged" if problem_count else "all clear",
                tone="danger" if problem_count else "success",
                badge_label="Attention" if problem_count else "OK",
            ),
            _stat(
                "Dirty",
                str(dirty_count),
                caption="uncommitted changes" if dirty_count else "working trees clean",
                tone="warning" if dirty_count else "success",
            ),
            _stat(
                "Off-Mainline",
                str(off_mainline_count),
                caption="parked on feature branches" if off_mainline_count else "all on default branch",
                tone="warning" if off_mainline_count else "success",
            ),
        ],
    }

    sections: list[dict[str, Any]] = [
        {
            "component": "section",
            "title": "Summary",
            "description": f"Last protected {_format_relative(status.get('last_successful_sync_at'))}.",
            "children": [summary_stats],
        }
    ]

    if top_attention:
        attention_children: list[dict[str, Any]] = []
        for repo in top_attention[:4]:
            tone = _protection_tone(str(repo.get("protection_state") or ""))
            attention_children.append(
                _stat(
                    str(repo.get("name") or "unknown"),
                    str(repo.get("protection_state") or ""),
                    caption=str(repo.get("attention_reason") or ""),
                    tone=tone,
                    badge_label=str(repo.get("problem_severity") or repo.get("protection_state") or "").title() or None,
                )
            )
        sections.append(
            {
                "component": "section",
                "title": "Top Attention",
                "description": "Ranked by attention score. Highest pressure first.",
                "children": [{"component": "grid", "columns": 2, "children": attention_children}],
            }
        )

    if problems:
        problem_children = []
        for problem in problems[:20]:
            severity = str(problem.get("severity") or "info")
            tone = _severity_tone(severity)
            title = str(problem.get("repo_name") or problem.get("path") or "Unknown repo")
            detail = str(problem.get("message") or "")
            hint = str(problem.get("fix_hint") or "")
            if hint:
                detail = f"{detail} — {hint}" if detail else hint
            problem_children.append(
                {
                    "component": "alert",
                    "tone": tone,
                    "title": title,
                    "message": detail or "No details recorded.",
                }
            )
        sections.append(
            {
                "component": "section",
                "title": f"Problems · {len(problems)}",
                "children": problem_children,
            }
        )

    sorted_repos = sorted(
        (r for r in repos if isinstance(r, dict)),
        key=lambda r: int(r.get("attention_score") or 0),
        reverse=True,
    )
    attention_rows = []
    for repo in sorted_repos[:40]:
        attention_rows.append(
            {
                "name": str(repo.get("name") or ""),
                "branch": str(repo.get("branch") or ""),
                "state": str(repo.get("protection_state") or ""),
                "reason": str(repo.get("attention_reason") or repo.get("problem_summary") or "quiet"),
                "tracked": str(repo.get("tracked_change_count") or 0),
                "untracked": str(repo.get("untracked_change_count") or 0),
                "ahead_behind": f"{repo.get('ahead') or 0} / {repo.get('behind') or 0}",
                "local": _format_relative(repo.get("last_local_change_at")),
                "score": str(repo.get("attention_score") or 0),
            }
        )

    sections.append(
        {
            "component": "section",
            "title": f"Attention Queue · top {len(attention_rows)} of {len(repos)}",
            "children": [
                {
                    "component": "table",
                    "columns": [
                        {"key": "name", "label": "Repo"},
                        {"key": "branch", "label": "Branch"},
                        {"key": "state", "label": "State"},
                        {"key": "reason", "label": "Reason"},
                        {"key": "tracked", "label": "Tracked"},
                        {"key": "untracked", "label": "Untracked"},
                        {"key": "ahead_behind", "label": "Ahead / Behind"},
                        {"key": "local", "label": "Local Touch"},
                        {"key": "score", "label": "Score"},
                    ],
                    "rows": attention_rows,
                }
            ],
        }
    )

    activity_rows = []
    for event in (activity or [])[:40]:
        if not isinstance(event, dict):
            continue
        activity_rows.append(
            {
                "when": _format_relative(event.get("timestamp")),
                "repo": str(event.get("repo_name") or ""),
                "kind": str(event.get("kind") or "event"),
                "severity": str(event.get("severity") or "info"),
                "summary": str(event.get("summary") or ""),
            }
        )

    sections.append(
        {
            "component": "section",
            "title": f"Recent Activity · {len(activity_rows)} events",
            "children": [
                {
                    "component": "table",
                    "columns": [
                        {"key": "when", "label": "When"},
                        {"key": "repo", "label": "Repo"},
                        {"key": "kind", "label": "Kind"},
                        {"key": "severity", "label": "Severity"},
                        {"key": "summary", "label": "Summary"},
                    ],
                    "rows": activity_rows,
                }
            ],
        }
    )

    return {
        "version": 1,
        "title": "Gitter Ops Cockpit",
        "description": f"Protecting {tracked} repos — {_cycle_status(status)}.",
        "page": {
            "component": "app",
            "title": "Gitter Ops Cockpit",
            "subtitle": f"Protecting {tracked} repos · {_cycle_status(status)}",
            "sections": sections,
        },
    }


def activity_payload(query: dict[str, list[str]]) -> dict[str, Any]:
    events = load_activity_events()
    path = (query.get("path") or [""])[0].strip()
    if path:
        events = [event for event in events if str(event.get("path") or "") == path]

    raw_limit = (query.get("limit") or ["200"])[0].strip()
    try:
        limit = max(1, min(500, int(raw_limit)))
    except ValueError:
        limit = 200

    events.sort(key=lambda event: str(event.get("timestamp") or ""), reverse=True)
    return {
        "events": events[:limit],
        "count": min(limit, len(events)),
    }


def effective_dashboard_url(server: ThreadingHTTPServer) -> str:
    host, port = server.server_address[:2]
    return dashboard_url(host=str(host), port=int(port))


def load_status_payload(server: ThreadingHTTPServer) -> dict[str, Any]:
    payload = load_json(STATUS_FILE, {})
    if not isinstance(payload, dict):
        payload = {}
    payload["dashboard_url"] = effective_dashboard_url(server)
    return payload


def build_handler(repo_root: Path, logger: Callable[[str, str], None] | None = None) -> type[BaseHTTPRequestHandler]:
    dashboard_file = repo_root / "dashboard.html"
    local_ui_root = (repo_root.parent / "ui").resolve()
    shared_ui_roots = {"js", "core", "active", "walmart", "mockup", "precog"}
    static_files = {
        "/dashboard.js": (repo_root / "dashboard.js", "text/javascript; charset=utf-8"),
        "/sitemap.json": (repo_root / "sitemap.json", "application/json; charset=utf-8"),
        "/favicon.ico": (repo_root / "favicon.ico", "image/x-icon"),
    }

    class GitterControlPlaneHandler(BaseHTTPRequestHandler):
        server_version = "GitterControlPlane/1.0"

        def log_message(self, format: str, *args: object) -> None:
            if logger:
                logger("INFO", "control-plane " + (format % args))

        def _send_json(self, payload: dict[str, Any], status_code: int = 200) -> None:
            body = json.dumps(payload, indent=2, sort_keys=False).encode("utf-8")
            self.send_response(status_code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _send_text(self, body: str, content_type: str = "text/html; charset=utf-8", status_code: int = 200) -> None:
            encoded = body.encode("utf-8")
            self.send_response(status_code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(encoded)

        def _send_file(self, path: Path, content_type: str, status_code: int = 200) -> None:
            encoded = path.read_bytes()
            self.send_response(status_code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(encoded)

        def _content_type_for(self, path: Path) -> str:
            content_type, _ = mimetypes.guess_type(str(path))
            if not content_type:
                return "application/octet-stream"
            if content_type.startswith("text/") or content_type in {"application/javascript", "application/json"}:
                return f"{content_type}; charset=utf-8"
            return content_type

        def _send_local_ui_asset(self, route: str) -> bool:
            relative_path: str | None = None
            if route == "/ui.js":
                relative_path = "ui.js"
            elif route.startswith("/ui/"):
                relative_path = route.removeprefix("/ui/")
            else:
                parts = route.lstrip("/").split("/", 1)
                if len(parts) == 2 and parts[0] in shared_ui_roots:
                    relative_path = "/".join(parts)

            if not relative_path:
                return False

            try:
                candidate = (local_ui_root / relative_path).resolve()
                candidate.relative_to(local_ui_root)
            except Exception:
                self._send_json({"error": f"Invalid UI asset path: {route}"}, status_code=404)
                return True

            if not candidate.is_file():
                self._send_json({"error": f"UI asset is missing: {route}"}, status_code=404)
                return True

            self._send_file(candidate, self._content_type_for(candidate))
            return True

        def _require_json_request(self) -> None:
            content_type = (self.headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
            if content_type in {"application/json", "text/json"} or content_type.endswith("+json"):
                return
            raise ValueError("JSON-only endpoints require Content-Type: application/json.")

        def _read_json_body(self) -> dict[str, Any]:
            self._require_json_request()

            raw_length = (self.headers.get("Content-Length") or "0").strip()
            try:
                length = int(raw_length or "0")
            except ValueError as error:
                raise ValueError("Content-Length must be an integer.") from error

            if length > MAX_JSON_BODY_BYTES:
                raise OverflowError(f"Request body is too large. Maximum allowed is {MAX_JSON_BODY_BYTES} bytes.")
            if length <= 0:
                return {}
            raw = self.rfile.read(length).decode("utf-8")
            if not raw.strip():
                return {}
            payload = json.loads(raw)
            if not isinstance(payload, dict):
                raise ValueError("Request body must be a JSON object.")
            return payload

        def _current_status(self) -> dict[str, Any]:
            return load_status_payload(self.server)

        def _find_repo(self, raw_path: str) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
            target = str(Path(raw_path).expanduser())
            status = self._current_status()
            repos = status.get("repos") if isinstance(status.get("repos"), list) else []
            problems = status.get("problems") if isinstance(status.get("problems"), list) else []
            repo = next((item for item in repos if isinstance(item, dict) and str(item.get("path") or "") == target), None)
            repo_problems = [problem for problem in problems if isinstance(problem, dict) and str(problem.get("path") or "") == target]
            return repo, repo_problems

        def _update_control(self, **changes: Any) -> dict[str, Any]:
            control = load_control()
            control.update(changes)
            save_control(control)
            return load_json(CONTROL_FILE, control)

        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            route = parsed.path or "/"
            query = parse_qs(parsed.query)

            if route in {"/", "/index.html", "/dashboard", "/dashboard.html"}:
                try:
                    self._send_text(dashboard_file.read_text(encoding="utf-8"))
                except FileNotFoundError:
                    self._send_json({"error": "Dashboard file is missing."}, status_code=404)
                return

            if route in static_files:
                file_path, content_type = static_files[route]
                try:
                    self._send_file(file_path, content_type)
                except FileNotFoundError:
                    self._send_json({"error": f"Static asset is missing: {route}"}, status_code=404)
                return

            if self._send_local_ui_asset(route):
                return

            if route == "/api/status":
                self._send_json(self._current_status())
                return

            if route == "/api/repos":
                status = self._current_status()
                self._send_json(
                    {
                        "repos": status.get("repos", []),
                        "sort": "attention",
                        "dashboard_url": status.get("dashboard_url"),
                    }
                )
                return

            if route == "/api/problems":
                status = self._current_status()
                self._send_json(
                    {
                        "problems": status.get("problems", []),
                        "generated_at": status.get("generated_at"),
                    }
                )
                return

            if route == "/api/activity":
                self._send_json(activity_payload(query))
                return

            if route == "/api/contract":
                status = self._current_status()
                problems = status.get("problems") if isinstance(status.get("problems"), list) else []
                activity = activity_payload({"limit": ["80"]}).get("events") or []
                self._send_json(build_contract(status, problems, activity))
                return

            self._send_json({"error": f"Unknown route: {route}"}, status_code=404)

        def do_POST(self) -> None:
            parsed = urlparse(self.path)
            route = parsed.path or "/"

            try:
                payload = self._read_json_body()
            except OverflowError as error:
                self._send_json({"error": str(error)}, status_code=413)
                return
            except json.JSONDecodeError:
                self._send_json({"error": "Request body was not valid JSON."}, status_code=400)
                return
            except ValueError as error:
                self._send_json({"error": str(error)}, status_code=400)
                return

            if route == "/api/control/run-now":
                self._send_json({"ok": True, "control": self._update_control(run_now=True, paused=False, force_pull=True)})
                return

            if route == "/api/control/pause":
                self._send_json({"ok": True, "control": self._update_control(paused=True)})
                return

            if route == "/api/control/resume":
                self._send_json({"ok": True, "control": self._update_control(paused=False)})
                return

            if route == "/api/repos/open":
                raw_path = str(payload.get("path") or "").strip()
                if not raw_path:
                    self._send_json({"error": "path is required."}, status_code=400)
                    return

                repo, _repo_problems = self._find_repo(raw_path)
                if repo is None:
                    self._send_json({"error": "Repo path is not currently tracked."}, status_code=404)
                    return

                target = Path(raw_path).expanduser()
                reveal = bool(payload.get("reveal"))
                terminal = bool(payload.get("terminal"))
                exit_code = open_in_terminal(target) if terminal else open_in_finder(target, reveal=reveal)
                if exit_code != 0:
                    self._send_json({"error": "Failed to open repo."}, status_code=500)
                    return

                self._send_json({"ok": True})
                return

            if route == "/api/repos/explain":
                raw_path = str(payload.get("path") or "").strip()
                if not raw_path:
                    self._send_json({"error": "path is required."}, status_code=400)
                    return

                repo, repo_problems = self._find_repo(raw_path)
                if repo is None:
                    self._send_json({"error": "Repo path is not currently tracked."}, status_code=404)
                    return

                try:
                    explanation = explain_repo(
                        repo_snapshot=repo,
                        problems=repo_problems,
                        diagnostics=collect_git_diagnostics(Path(raw_path)),
                    )
                except AIConfigError as error:
                    self._send_json({"error": str(error)}, status_code=503)
                    return
                except AIExplanationError as error:
                    self._send_json({"error": str(error)}, status_code=502)
                    return

                self._send_json({"ok": True, "explanation": explanation})
                return

            self._send_json({"error": f"Unknown route: {route}"}, status_code=404)

    return GitterControlPlaneHandler


def start_control_plane(
    host: str = CONTROL_PLANE_HOST,
    port: int = CONTROL_PLANE_PORT,
    repo_root: Path = ROOT_DIR,
    logger: Callable[[str, str], None] | None = None,
) -> tuple[ThreadingHTTPServer, Thread]:
    server = ThreadingHTTPServer((host, port), build_handler(repo_root=repo_root, logger=logger))
    server.daemon_threads = True
    thread = Thread(target=server.serve_forever, name="gitter-control-plane", daemon=True)
    thread.start()
    if logger:
        logger("INFO", f"Started control plane at {control_plane_origin(host=host, port=server.server_address[1])}")
    return server, thread


def stop_control_plane(server: ThreadingHTTPServer | None, thread: Thread | None = None) -> None:
    if server is None:
        return
    server.shutdown()
    server.server_close()
    if thread is not None:
        thread.join(timeout=2)
