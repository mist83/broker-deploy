# gitter

Gitter is a local-first Git safety net for `/Users/mist83/Code`.

It now runs as two pieces:

- `gitterd.py`: a long-running daemon that watches tracked repos for local changes, auto-commits them, pushes them, and only fetches/pulls on a slower reconciliation cadence.
- `mac-menu-bar/GitterMenuBar.js`: a native macOS menu bar app that shows protection status, last protected time, current attention items, and the built-in settings window.
- `Gitter.Web`: a thin ASP.NET Core operator shell that wraps the daemon API, serves a `ui.mullmania.com` surface, and streams live snapshot updates into a browser-friendly cockpit.

The daemon still exposes its loopback-only cockpit at `http://127.0.0.1:9477/`. The canonical browser entrypoint is the ASP.NET wrapper at `http://127.0.0.1:9481/` when it is running.

## Static Deploy

- GitHub Pages can publish the repository root as a static launcher surface.
- Mullmania can mirror the repository root for the same launcher surface.
- `./smoke.sh` verifies that the launcher entrypoint renders locally.

## Current Behavior

- Tracks Git repos found under the configured root path.
- Uses `watchfiles` on macOS for event-driven local syncs when available, with timer-based polling as the fallback.
- Writes live state to `runtime/status.json`.
- Writes a rolling activity log to `runtime/activity.jsonl`.
- Writes a human-readable problem report to `runtime/problems.txt`.
- Auto-commits and pushes mainline repos shortly after local filesystem changes.
- Reconciles the full tree on `interval_seconds`, and only fetches/pulls on `pull_every_cycles` reconciliation passes.
- Automatically rebases clean diverged repos when a non-fast-forward push or pull is otherwise safe to resolve.
- Only initializes non-git directories when `enable_new_repo_init=true`.
- Ranks repos by attention so the most urgent or recently touched work floats to the top.
- Serves a local dashboard and JSON API from the daemon for repo lists, problems, activity, and control actions.
- Serves a separate ASP.NET Core cockpit that consumes the daemon API, keeps the browser UI loopback-only, and uses server-sent events for a live operator view without inventing a second source of truth.
- Supports `ignored_paths`, `ignored_path_globs`, and per-directory `.gitter-ignore` markers so fixture repos and scratch trees stay out of the tracked set.
- Treats common generated junk as non-blocking untracked noise instead of auto-committing it. Current allowlist covers folders like `bin`, `obj`, `node_modules`, `.claude`, `.playwright-cli`, `App_Data/_generated`, and the `output/demo-video` render tree.
- Refuses to auto-commit or auto-push repos parked on non-mainline branches. `main` and `master` are the only protected branches.

## Local Config

Copy `gitter.example.json` to `gitter.local.json` and set:

- `root_path`
- `github_username`
- `github_org`
- `interval_seconds`
- `pull_every_cycles`
- `use_file_watcher`
- `event_debounce_seconds`
- `enable_new_repo_init`
- `auto_create_missing_repos`
- `auto_rebase_divergent_repos`
- `ignored_paths`
- `ignored_path_globs`

This repo already uses a local `gitter.local.json` on this Mac.

Ignore list rule of thumb:

- `ignored_paths` is for exact known paths like `showcase-workaround/showcase`.
- `ignored_path_globs` is for wildcard patterns like `*/fixtures/*` or `**/node_modules/*`.

## Main Commands

Run the daemon in the foreground:

```bash
python3 -m pip install --user -r requirements.txt
./run-gitterd.sh
```

Run the ASP.NET Core cockpit:

```bash
/bin/zsh run-gitter-web.sh
```

Run one cycle only:

```bash
python3 gitterd.py --once
```

Use the compatibility wrapper:

```bash
./sync.sh /Users/mist83/Code mist83
```

Control the daemon:

```bash
python3 gitterctl.py status
python3 gitterctl.py audit
python3 gitterctl.py pause
python3 gitterctl.py resume
python3 gitterctl.py run-now
python3 gitterctl.py sync-now
python3 gitterctl.py open-dashboard
```

Build the menu bar app:

```bash
/bin/zsh build-menu-bar.sh
```

Build the ASP.NET Core cockpit:

```bash
dotnet build Gitter.Web/Gitter.Web.csproj
```

Install the daemon at login:

```bash
/bin/zsh install-launchd.sh
```

Install the ASP.NET Core cockpit at login:

```bash
/bin/zsh install-web-launchd.sh
```

Install the menu bar app at login:

```bash
/bin/zsh install-menubar-login.sh
```

Run the tests:

```bash
python3 -m unittest discover -s tests -v
```

## Notes

- The daemon is intentionally conservative with remote pulls. It only auto-pulls when a repo is clean and fast-forwardable.
- Generated junk is ignored for dirty-state decisions, but tracked changes still count. If you checked build output into Git, Gitter will still treat edits there as real work.
- Non-mainline branches are visible in the cockpit, but automation will not commit or push them for you.
- `run-now` and `sync-now` force an immediate full reconcile, including remote fetch/pull work, instead of waiting for the normal pull cadence.
- New top-level project folders are only auto-initialized when `enable_new_repo_init=true`.
- Missing GitHub remotes are created with authenticated `gh` CLI when available; otherwise Git falls back to your normal local credentials.
- Local file watching is advisory, not magic. A slower reconciliation pass still runs so new repos, deleted repos, and missed events get corrected instead of becoming folklore.
- Clean diverged repos are rebased automatically when possible; conflicts still stop and are reported instead of being forced through.
- Runtime files live under `runtime/` and are ignored by Git.
- The dashboard and control API are loopback-only and intentionally local.
- `open-dashboard` prefers the ASP.NET Core wrapper when it is live and falls back to the daemon dashboard otherwise.
- The optional AI explainer is disabled by default. Set `OPENAI_API_KEY` and `GITTER_AI_MODEL` if you want `/api/repos/explain` to work.
