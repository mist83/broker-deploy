#!/bin/zsh
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG_PATH="${GITTER_CONFIG:-$ROOT_DIR/gitter.local.json}"

ARGS=()
if [[ -f "$CONFIG_PATH" ]]; then
  ARGS+=(--config "$CONFIG_PATH")
fi

exec /usr/bin/python3 "$ROOT_DIR/gitterd.py" "${ARGS[@]}" "$@"
