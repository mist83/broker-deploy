#!/usr/bin/env python3
from __future__ import annotations

import argparse
import fnmatch
import os
import shutil
import signal
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from threading import Event
from typing import Any

from gitterapi import start_control_plane, stop_control_plane
from gitterlib import (
    ACTIVITY_FILE,
    CONTROL_FILE,
    EXCLUDED_DIR_NAMES,
    LOG_DIR,
    PID_FILE,
    PROJECT_MARKERS,
    REPORT_FILE,
    ROOT_DIR,
    STATUS_FILE,
    atomic_write_json,
    atomic_write_text,
    dashboard_url,
    ensure_runtime_dirs,
    format_timestamp,
    iso_now,
    load_config,
    load_control,
    load_json,
    save_control,
)
from gitterops import (
    append_activity_events,
    enrich_repo_snapshot,
    finalize_status_payload,
    load_activity_events,
)

try:
    from watchfiles import watch

    WATCHFILES_AVAILABLE = True
except ImportError:
    watch = None
    WATCHFILES_AVAILABLE = False


STOP_REQUESTED = False
STOP_EVENT = Event()
UNSET = object()

MAINLINE_BRANCHES = ("main", "master")
GENERATED_DIR_NAMES = {
    ".cache",
    ".claude",
    ".next",
    ".nuxt",
    ".parcel-cache",
    ".playwright-cli",
    ".pytest_cache",
    ".sass-cache",
    ".serverless",
    ".terraform",
    ".turbo",
    ".venv",
    ".yarn",
    "__pycache__",
    "bin",
    "build",
    "coverage",
    "dist",
    "node_modules",
    "obj",
    "target",
    "temp",
    "tmp",
    "venv",
}
GENERATED_FILE_NAMES = {".DS_Store"}
GENERATED_FILE_SUFFIXES = (".cache", ".pyc", ".pdb", ".pyo")
GENERATED_PATH_GLOBS = (
    ".claude/**",
    ".playwright-cli/**",
    "App_Data/_generated/**",
    "output/demo-video/**",
)


@dataclass
class WorktreeSnapshot:
    tracked_changes: list[dict[str, str]] = field(default_factory=list)
    untracked_paths: list[str] = field(default_factory=list)
    generated_untracked_paths: list[str] = field(default_factory=list)

    @property
    def tracked_change_count(self) -> int:
        return len(self.tracked_changes)

    @property
    def untracked_change_count(self) -> int:
        return len(self.untracked_paths)

    @property
    def generated_untracked_count(self) -> int:
        return len(self.generated_untracked_paths)

    @property
    def dirty(self) -> bool:
        return self.tracked_change_count > 0 or self.untracked_change_count > 0


def log(level: str, message: str) -> None:
    print(f"{time.strftime('%Y-%m-%d %H:%M:%S')} [{level}] {message}", flush=True)


def command_exists(name: str) -> bool:
    return shutil.which(name) is not None


def run_command(args: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        cwd=str(cwd) if cwd else None,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


def git(repo_path: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return run_command(["git", *args], cwd=repo_path)


def strip_output(process: subprocess.CompletedProcess[str]) -> str:
    return (process.stdout or process.stderr or "").strip()


def resolve_path(path: Path) -> Path:
    return path.expanduser().resolve(strict=False)


def normalize_configured_path(raw_path: str, root_path: Path) -> Path:
    configured = Path(raw_path).expanduser()
    if not configured.is_absolute():
        configured = root_path / configured
    return resolve_path(configured)


def is_ignored_path(path: Path, config: dict[str, Any]) -> bool:
    resolved_path = resolve_path(path)
    root_path = resolve_path(Path(config["root_path"]))

    marker_path = resolved_path / ".gitter-ignore"
    if marker_path.exists():
        return True

    for raw_path in config.get("ignored_paths", []):
        ignored_path = normalize_configured_path(raw_path, root_path)
        if resolved_path == ignored_path or ignored_path in resolved_path.parents:
            return True

    try:
        relative_path = resolved_path.relative_to(root_path).as_posix()
    except ValueError:
        relative_path = resolved_path.as_posix()

    absolute_path = resolved_path.as_posix()
    for pattern in config.get("ignored_path_globs", []):
        if fnmatch.fnmatch(relative_path, pattern) or fnmatch.fnmatch(absolute_path, pattern):
            return True

    return False


def current_branch(repo_path: Path) -> str:
    result = git(repo_path, "symbolic-ref", "--short", "-q", "HEAD")
    branch = result.stdout.strip()
    return branch or "HEAD"


def default_branch_name(repo_path: Path) -> str | None:
    result = git(repo_path, "symbolic-ref", "--short", "-q", "refs/remotes/origin/HEAD")
    branch = result.stdout.strip()
    if result.returncode == 0 and branch:
        return branch.removeprefix("origin/")

    for candidate in MAINLINE_BRANCHES:
        if git(repo_path, "show-ref", "--verify", f"refs/heads/{candidate}").returncode == 0:
            return candidate
        if git(repo_path, "show-ref", "--verify", f"refs/remotes/origin/{candidate}").returncode == 0:
            return candidate

    branch = current_branch(repo_path)
    return None if branch == "HEAD" else branch


def is_mainline_branch(branch: str) -> bool:
    return branch in MAINLINE_BRANCHES


def normalize_status_path(raw_path: str) -> str:
    path = raw_path
    if " -> " in path:
        path = path.split(" -> ", 1)[1]
    return path.strip()


def is_generated_path(path_text: str) -> bool:
    path = PurePosixPath(str(path_text).strip())
    parts = [part for part in path.parts if part not in {"", "."}]
    if not parts:
        return False

    for part in parts[:-1]:
        if part in GENERATED_DIR_NAMES:
            return True

    name = parts[-1]
    if name in GENERATED_DIR_NAMES or name in GENERATED_FILE_NAMES:
        return True
    if any(name.endswith(suffix) for suffix in GENERATED_FILE_SUFFIXES):
        return True

    relative_path = "/".join(parts)
    return any(path.match(pattern) or fnmatch.fnmatch(relative_path, pattern) for pattern in GENERATED_PATH_GLOBS)


def collect_worktree_snapshot(repo_path: Path) -> WorktreeSnapshot:
    result = git(repo_path, "status", "--porcelain=v1", "--untracked-files=all")
    snapshot = WorktreeSnapshot()
    if result.returncode != 0 or not result.stdout.strip():
        return snapshot

    for line in result.stdout.splitlines():
        if len(line) < 4:
            continue

        code = line[:2]
        path = normalize_status_path(line[3:])
        if not path:
            continue

        if code == "??":
            if is_generated_path(path):
                snapshot.generated_untracked_paths.append(path)
            else:
                snapshot.untracked_paths.append(path)
            continue

        snapshot.tracked_changes.append(
            {
                "code": code.strip() or code,
                "path": path,
            }
        )

    return snapshot


def apply_worktree_snapshot(info: dict[str, Any], snapshot: WorktreeSnapshot) -> None:
    info["dirty"] = snapshot.dirty
    info["tracked_change_count"] = snapshot.tracked_change_count
    info["untracked_change_count"] = snapshot.untracked_change_count
    info["generated_untracked_count"] = snapshot.generated_untracked_count
    info["tracked_changes_sample"] = list(snapshot.tracked_changes[:8])
    info["untracked_changes_sample"] = list(snapshot.untracked_paths[:8])
    info["generated_untracked_sample"] = list(snapshot.generated_untracked_paths[:8])


def repo_dirty(repo_path: Path) -> bool:
    return collect_worktree_snapshot(repo_path).dirty


def repo_name(repo_path: Path) -> str:
    return repo_path.name


def has_origin_remote(repo_path: Path) -> bool:
    return git(repo_path, "remote", "get-url", "origin").returncode == 0


def origin_url(repo_path: Path) -> str | None:
    result = git(repo_path, "remote", "get-url", "origin")
    return result.stdout.strip() if result.returncode == 0 else None


def parse_github_remote(remote_url: str | None) -> tuple[str, str] | None:
    remote = str(remote_url or "").strip()
    if not remote:
        return None

    tail = ""
    if remote.startswith("git@github.com:"):
        tail = remote.split(":", 1)[1]
    elif "github.com/" in remote:
        tail = remote.split("github.com/", 1)[1]
    else:
        return None

    tail = tail.strip().strip("/")
    if tail.endswith(".git"):
        tail = tail[:-4]

    parts = [part for part in tail.split("/") if part]
    if len(parts) < 2:
        return None
    return parts[0], parts[1]


def upstream_name(repo_path: Path) -> str | None:
    result = git(repo_path, "rev-parse", "--abbrev-ref", "@{upstream}")
    upstream = result.stdout.strip()
    return upstream if result.returncode == 0 and upstream else None


def ahead_behind(repo_path: Path, upstream: str | None) -> tuple[int, int]:
    if not upstream:
        return 0, 0

    result = git(repo_path, "rev-list", "--left-right", "--count", f"HEAD...{upstream}")
    if result.returncode != 0:
        return 0, 0

    parts = result.stdout.strip().split()
    if len(parts) != 2:
        return 0, 0

    try:
        return int(parts[0]), int(parts[1])
    except ValueError:
        return 0, 0


def project_type(directory: Path) -> str:
    if list(directory.glob("*.csproj")) or list(directory.glob("*.sln")):
        return "csharp"
    if (directory / "package.json").exists():
        return "nodejs"
    return "basic"


def has_git_repo_in_subtree(directory: Path) -> bool:
    for current_root, dirnames, _filenames in os.walk(directory):
        if current_root != str(directory) and ".git" in dirnames:
            return True
        dirnames[:] = [name for name in dirnames if name not in EXCLUDED_DIR_NAMES]
    return False


def should_initialize_non_git_dir(directory: Path) -> bool:
    for marker in PROJECT_MARKERS:
        if (directory / marker).exists():
            return True

    return project_type(directory) != "basic"


def scan_directories(root_path: Path, config: dict[str, Any]) -> tuple[list[Path], list[Path]]:
    repos: list[Path] = []
    init_candidates: list[Path] = []
    enable_new_repo_init = bool(config["enable_new_repo_init"])

    for current_root, dirnames, _filenames in os.walk(root_path):
        current_path = Path(current_root)

        if current_path != root_path and is_ignored_path(current_path, config):
            dirnames[:] = []
            continue

        if ".git" in dirnames:
            repos.append(current_path)
            dirnames[:] = []
            continue

        filtered_dirnames: list[str] = []
        for name in sorted(dirnames):
            if name in EXCLUDED_DIR_NAMES:
                continue
            child_path = current_path / name
            if is_ignored_path(child_path, config):
                continue
            filtered_dirnames.append(name)
        dirnames[:] = filtered_dirnames

        if not enable_new_repo_init or current_path == root_path or current_path.parent != root_path:
            continue

        try:
            has_content = any(current_path.iterdir())
        except OSError:
            has_content = False

        if not has_content:
            continue

        if has_git_repo_in_subtree(current_path):
            continue

        if should_initialize_non_git_dir(current_path):
            init_candidates.append(current_path)

    return sorted(repos), sorted(init_candidates)


def get_basic_gitignore() -> str:
    return """# OS generated files
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# Temporary files
*.tmp
*.temp
*~

# Editor files
.vscode/
.idea/
*.swp
*.swo

# Log files
*.log
"""


def get_node_gitignore() -> str:
    return """# Logs
logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Dependency directories
node_modules/

# TypeScript cache
*.tsbuildinfo

# Optional npm cache directory
.npm

# Optional eslint cache
.eslintcache

# dotenv environment variables file
.env
.env.test

# parcel-bundler cache
.cache
.parcel-cache

# Next.js build output
.next

# Nuxt.js build / generate output
.nuxt
dist

# Gatsby files
.cache/

# Serverless directories
.serverless/

# macOS
.DS_Store
.AppleDouble
.LSOverride
"""


def get_csharp_gitignore() -> str:
    return """# User-specific files
*.rsuser
*.suo
*.user
*.userosscache
*.sln.docstates

# Build results
[Dd]ebug/
[Dd]ebugPublic/
[Rr]elease/
[Rr]eleases/
x64/
x86/
[Aa][Rr][Mm]/
[Aa][Rr][Mm]64/
bld/
[Bb]in/
[Oo]bj/
[Ll]og/

# Visual Studio cache/options directory
.vs/

# Node.js (if mixed project)
node_modules/

# macOS
.DS_Store
.AppleDouble
.LSOverride
"""


def ensure_gitignore(directory: Path) -> None:
    gitignore_path = directory / ".gitignore"
    if gitignore_path.exists():
        return

    kind = project_type(directory)
    content = get_basic_gitignore()
    if kind == "nodejs":
        content = get_node_gitignore()
    elif kind == "csharp":
        content = get_csharp_gitignore()

    gitignore_path.write_text(content, encoding="utf-8")


def initialize_repo(directory: Path, config: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    info = {
        "name": directory.name,
        "path": str(directory),
        "branch": "main",
        "default_branch": "main",
        "off_mainline": False,
        "remote_url": None,
        "dirty": False,
        "tracked_change_count": 0,
        "untracked_change_count": 0,
        "generated_untracked_count": 0,
        "tracked_changes_sample": [],
        "untracked_changes_sample": [],
        "generated_untracked_sample": [],
        "ahead": 0,
        "behind": 0,
        "last_action": "new repo detected",
        "last_sync_at": iso_now(),
        "last_pull_at": None,
    }
    problems: list[dict[str, Any]] = []

    ensure_gitignore(directory)

    if git(directory, "init").returncode != 0:
        problems.append(
            problem_entry(directory, "Could not initialize a new git repository.", "Inspect the directory permissions and try again.")
        )
        return info, problems

    branch = current_branch(directory)
    if branch != "main":
        git(directory, "branch", "-M", "main")
        branch = "main"

    git(directory, "add", "-A")
    commit_message = f"Initial commit - {time.strftime('%Y-%m-%d %H:%M:%S')}"
    commit_result = git(directory, "commit", "-m", commit_message)
    if commit_result.returncode != 0 and repo_dirty(directory):
        problems.append(
            problem_entry(directory, "Initial commit failed.", strip_output(commit_result) or "Git refused to create the initial commit.")
        )
        return info, problems

    ok, remote_problem, action = ensure_origin_remote(directory, config, branch)
    info["branch"] = branch
    info["remote_url"] = origin_url(directory)
    info["last_action"] = action or info["last_action"]

    if not ok and remote_problem:
        problems.append(remote_problem)
        return info, problems

    info["last_action"] = "initialized and pushed"
    return info, problems


def problem_entry(directory: Path, message: str, fix_hint: str, severity: str = "error") -> dict[str, Any]:
    return {
        "repo_name": directory.name,
        "path": str(directory),
        "severity": severity,
        "message": message,
        "fix_hint": fix_hint,
    }


def ensure_origin_remote(directory: Path, config: dict[str, Any], branch: str) -> tuple[bool, dict[str, Any] | None, str | None]:
    if has_origin_remote(directory):
        return True, None, None

    owner = config.get("github_org") or config.get("github_username")
    if not owner:
        return False, problem_entry(directory, "Repo has no origin remote.", "Set github_username or github_org in the gitter config."), None

    if not config.get("auto_create_missing_repos", True):
        return False, problem_entry(directory, "Repo has no origin remote.", "Enable auto_create_missing_repos or create the GitHub repo manually."), None

    remote_url = f"https://github.com/{owner}/{directory.name}.git"

    if command_exists("gh"):
        visibility = "--private"
        if str(config.get("repo_visibility", "private")).lower() == "public":
            visibility = "--public"

        create_result = run_command(
            [
                "gh",
                "repo",
                "create",
                f"{owner}/{directory.name}",
                visibility,
                "--source=.",
                "--remote=origin",
                "--push",
            ],
            cwd=directory,
        )

        if create_result.returncode == 0:
            return True, None, "created GitHub remote"

    git(directory, "remote", "remove", "origin")
    git(directory, "remote", "add", "origin", remote_url)
    push_result = git(directory, "push", "-u", "origin", branch)
    if push_result.returncode == 0:
        return True, None, "connected GitHub remote"

    return (
        False,
        problem_entry(
            directory,
            "Repo has no usable origin remote.",
            strip_output(push_result) or f"Create {remote_url} manually, then run a sync again.",
        ),
        None,
    )


def commit_all_changes(directory: Path) -> tuple[bool, str | None]:
    snapshot = collect_worktree_snapshot(directory)
    if not snapshot.dirty:
        return False, None

    git(directory, "add", "-u")
    for start in range(0, snapshot.untracked_change_count, 64):
        batch = snapshot.untracked_paths[start : start + 64]
        if batch:
            git(directory, "add", "--", *batch)

    if git(directory, "diff", "--cached", "--quiet").returncode == 0:
        return False, None

    message = f"Auto-commit - {time.strftime('%Y-%m-%d %H:%M:%S')}"
    result = git(directory, "commit", "-m", message)
    if result.returncode != 0 and repo_dirty(directory):
        raise RuntimeError(strip_output(result) or "git commit failed")

    return result.returncode == 0, message


def fetch_origin(directory: Path) -> tuple[bool, str | None]:
    result = git(directory, "fetch", "--prune", "origin")
    if result.returncode == 0:
        return True, None
    return False, strip_output(result) or "git fetch failed"


def should_recover_missing_github_origin(directory: Path, config: dict[str, Any], error_text: str | None) -> bool:
    if "repository not found" not in str(error_text or "").lower():
        return False

    if not config.get("auto_create_missing_repos", True):
        return False

    owner = str(config.get("github_org") or config.get("github_username") or "").strip().lower()
    if not owner:
        return False

    remote = parse_github_remote(origin_url(directory))
    if not remote:
        return False

    remote_owner, remote_name = remote
    return remote_owner.lower() == owner and remote_name.lower() == directory.name.lower()


def recover_missing_origin_remote(directory: Path, config: dict[str, Any], branch: str) -> tuple[bool, dict[str, Any] | None, str | None]:
    if has_origin_remote(directory):
        git(directory, "remote", "remove", "origin")

    ok, remote_problem, _action = ensure_origin_remote(directory, config, branch)
    if ok:
        return True, None, "recreated GitHub remote"
    return False, remote_problem, None


def fetch_origin_with_recovery(
    directory: Path,
    config: dict[str, Any],
    branch: str,
) -> tuple[bool, dict[str, Any] | None, list[str]]:
    ok, error_text = fetch_origin(directory)
    if ok:
        return True, None, ["fetched"]

    if not should_recover_missing_github_origin(directory, config, error_text):
        return False, problem_entry(directory, "Fetching remote changes failed.", error_text), []

    recovered, remote_problem, recovery_action = recover_missing_origin_remote(directory, config, branch)
    if not recovered:
        return False, remote_problem, []

    ok, error_text = fetch_origin(directory)
    if ok:
        actions = [recovery_action] if recovery_action else []
        actions.append("fetched")
        return True, None, actions

    return (
        False,
        problem_entry(directory, "Fetching remote changes failed.", error_text),
        [recovery_action] if recovery_action else [],
    )


def pull_fast_forward(directory: Path) -> tuple[bool, str | None]:
    result = git(directory, "pull", "--ff-only")
    if result.returncode == 0:
        return True, None
    return False, strip_output(result) or "git pull --ff-only failed"


def pull_rebase(directory: Path) -> tuple[bool, str | None]:
    result = git(directory, "pull", "--rebase", "--autostash")
    if result.returncode == 0:
        return True, None

    git(directory, "rebase", "--abort")
    return False, strip_output(result) or "git pull --rebase failed"


def push_branch(directory: Path, branch: str, set_upstream: bool = False) -> tuple[bool, str | None]:
    args = ["push"]
    if set_upstream:
        args.extend(["-u", "origin", branch])
    result = git(directory, *args)
    if result.returncode == 0:
        return True, None
    return False, strip_output(result) or "git push failed"


@dataclass
class RepoOutcome:
    info: dict[str, Any]
    problems: list[dict[str, Any]]


@dataclass
class RuntimeState:
    config: dict[str, Any]
    config_path: Path | None
    root_path: Path
    next_cycle_number: int
    watcher_enabled: bool
    watcher_backend: str
    status: dict[str, Any] = field(default_factory=dict)
    tracked_repos: list[Path] = field(default_factory=list)
    tracked_repo_keys: set[str] = field(default_factory=set)
    repo_info_by_path: dict[str, dict[str, Any]] = field(default_factory=dict)
    problems_by_path: dict[str, list[dict[str, Any]]] = field(default_factory=dict)
    init_candidates: list[Path] = field(default_factory=list)
    pending_repos: set[str] = field(default_factory=set)
    activity_log: list[dict[str, Any]] = field(default_factory=list)


def watcher_backend_for_config(config: dict[str, Any]) -> tuple[bool, str]:
    if not config.get("use_file_watcher", True):
        return False, "disabled"
    if sys.platform != "darwin":
        return False, "polling"
    if not WATCHFILES_AVAILABLE:
        return False, "polling"
    return True, "watchfiles"


def status_path_key(path: Path | str) -> str:
    return str(resolve_path(Path(path)))


def set_tracked_repos(state: RuntimeState, repos: list[Path]) -> None:
    resolved = {status_path_key(repo): resolve_path(repo) for repo in repos}
    state.tracked_repo_keys = set(resolved)
    state.tracked_repos = [resolved[key] for key in sorted(resolved)]

    for key in list(state.repo_info_by_path):
        if key not in state.tracked_repo_keys:
            state.repo_info_by_path.pop(key, None)
            state.problems_by_path.pop(key, None)


def problem_signature(problem: dict[str, Any]) -> str:
    return f"{problem.get('severity', 'error')}::{problem.get('message', '')}"


def record_activity_entries(state: RuntimeState, entries: list[dict[str, Any]]) -> None:
    if not entries:
        return
    state.activity_log = append_activity_events(entries, existing_events=state.activity_log, path=ACTIVITY_FILE)


def activity_event(
    path: str | Path,
    repo_name: str,
    kind: str,
    summary: str,
    severity: str = "info",
    **extra: Any,
) -> dict[str, Any]:
    event = {
        "timestamp": iso_now(),
        "path": str(path),
        "repo_name": repo_name,
        "kind": kind,
        "summary": summary,
        "severity": severity,
    }
    event.update(extra)
    return event


def record_problem_events(
    state: RuntimeState,
    path: str | Path,
    repo_name: str,
    previous_problems: list[dict[str, Any]],
    problems: list[dict[str, Any]],
) -> None:
    previous_by_signature = {problem_signature(problem): problem for problem in previous_problems}
    current_by_signature = {problem_signature(problem): problem for problem in problems}
    entries: list[dict[str, Any]] = []

    for signature, problem in current_by_signature.items():
        if signature in previous_by_signature:
            continue
        entries.append(
            activity_event(
                path,
                repo_name,
                "problem_detected",
                str(problem.get("message") or "Problem detected"),
                severity=str(problem.get("severity") or "error"),
                fix_hint=str(problem.get("fix_hint") or ""),
            )
        )

    for signature, problem in previous_by_signature.items():
        if signature in current_by_signature:
            continue
        entries.append(
            activity_event(
                path,
                repo_name,
                "problem_resolved",
                str(problem.get("message") or "Problem resolved"),
                severity="info",
            )
        )

    record_activity_entries(state, entries)


def restore_previous_runtime_state(state: RuntimeState) -> None:
    previous_status = load_json(STATUS_FILE, {})
    if not isinstance(previous_status, dict):
        return

    previous_problems_by_path: dict[str, list[dict[str, Any]]] = {}
    previous_problems = previous_status.get("problems")
    if isinstance(previous_problems, list):
        for raw_problem in previous_problems:
            if not isinstance(raw_problem, dict) or not raw_problem.get("path"):
                continue
            key = status_path_key(raw_problem["path"])
            previous_problems_by_path.setdefault(key, []).append(dict(raw_problem))

    previous_repos: list[Path] = []
    raw_repos = previous_status.get("repos")
    if isinstance(raw_repos, list):
        for raw_repo in raw_repos:
            if not isinstance(raw_repo, dict) or not raw_repo.get("path"):
                continue
            key = status_path_key(raw_repo["path"])
            enriched = enrich_repo_snapshot(
                raw_repo,
                previous_problems_by_path.get(key, []),
                previous_info=raw_repo,
                activity_events=state.activity_log,
                interval_seconds=int(state.config["interval_seconds"]),
            )
            state.repo_info_by_path[key] = enriched
            previous_repos.append(Path(str(raw_repo["path"])))

    for key, problems in previous_problems_by_path.items():
        state.problems_by_path[key] = list(problems)

    if previous_repos:
        set_tracked_repos(state, previous_repos)


def set_repo_snapshot(state: RuntimeState, info: dict[str, Any], problems: list[dict[str, Any]]) -> None:
    key = status_path_key(info["path"])
    previous_info = state.repo_info_by_path.get(key)
    previous_problems = state.problems_by_path.get(key, [])
    resolved_repo_name = str(info.get("name") or Path(str(info["path"])).name)

    entries: list[dict[str, Any]] = []
    if str(info.get("last_action") or "") not in {"", "checked", "new repo detected"}:
        kind = "repo_initialized" if str(info.get("last_action") or "").startswith("initialized") else "sync_action"
        entries.append(
            activity_event(
                info["path"],
                resolved_repo_name,
                kind,
                str(info.get("last_action") or "Repository updated"),
                severity="info",
            )
        )
    record_activity_entries(state, entries)
    record_problem_events(state, info["path"], resolved_repo_name, previous_problems, problems)

    state.repo_info_by_path[key] = enrich_repo_snapshot(
        info,
        problems,
        previous_info=previous_info,
        activity_events=state.activity_log,
        interval_seconds=int(state.config["interval_seconds"]),
    )
    state.problems_by_path[key] = list(problems)


def set_path_problems(state: RuntimeState, path: Path, problems: list[dict[str, Any]]) -> None:
    key = status_path_key(path)
    previous_problems = state.problems_by_path.get(key, [])
    record_problem_events(state, path, path.name, previous_problems, problems)
    if problems:
        state.problems_by_path[key] = list(problems)
    else:
        state.problems_by_path.pop(key, None)
    if key not in state.tracked_repo_keys:
        state.repo_info_by_path.pop(key, None)


def format_deadline(deadline: float | None) -> str | None:
    if deadline is None:
        return None
    return time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(deadline))


def sync_runtime_collections(state: RuntimeState) -> None:
    repos = [state.repo_info_by_path[key] for key in sorted(state.repo_info_by_path)]
    problems: list[dict[str, Any]] = []
    for key in sorted(state.problems_by_path):
        problems.extend(state.problems_by_path[key])

    state.status["repos"] = repos
    state.status["problems"] = problems
    state.status["tracked_repo_count"] = len(state.tracked_repos)
    state.status["problem_count"] = len(problems)
    state.status["problem_repo_count"] = unique_problem_repo_count(problems)
    state.status["new_repo_candidates"] = [str(path) for path in state.init_candidates]
    state.status["pending_repo_count"] = len(state.pending_repos)
    state.status["watcher_enabled"] = state.watcher_enabled
    state.status["watcher_backend"] = state.watcher_backend
    state.status["config_path"] = str(state.config_path) if state.config_path else None
    state.status["dashboard_url"] = dashboard_url()


def write_runtime_state(state: RuntimeState) -> None:
    sync_runtime_collections(state)
    write_status(state.status, activity_events=state.activity_log)


def build_runtime_state(config: dict[str, Any], config_path: Path | None, cycle_number: int) -> RuntimeState:
    watcher_enabled, watcher_backend = watcher_backend_for_config(config)
    status = build_base_status(config, cycle_number=cycle_number)
    status["config_path"] = str(config_path) if config_path else None
    status["watcher_enabled"] = watcher_enabled
    status["watcher_backend"] = watcher_backend

    state = RuntimeState(
        config=config,
        config_path=config_path,
        root_path=Path(config["root_path"]).expanduser(),
        next_cycle_number=cycle_number,
        watcher_enabled=watcher_enabled,
        watcher_backend=watcher_backend,
        status=status,
        activity_log=load_activity_events(path=ACTIVITY_FILE),
    )
    restore_previous_runtime_state(state)
    return state


def has_commits(directory: Path) -> bool:
    return git(directory, "rev-parse", "--verify", "HEAD").returncode == 0


def remote_branch_exists(directory: Path, branch: str) -> bool:
    return git(directory, "ls-remote", "--exit-code", "--heads", "origin", branch).returncode == 0


def set_upstream_to_origin(directory: Path, branch: str) -> tuple[bool, str | None]:
    result = git(directory, "branch", "--set-upstream-to", f"origin/{branch}", branch)
    if result.returncode == 0:
        return True, None
    return False, strip_output(result) or "could not set upstream branch"


def should_retry_after_push_rejection(error_text: str | None) -> bool:
    if not error_text:
        return False

    lowered = error_text.lower()
    return "fetch first" in lowered or "non-fast-forward" in lowered


def process_repo(directory: Path, config: dict[str, Any], should_pull: bool) -> RepoOutcome:
    observed_local_change_at: str | None = None
    branch = current_branch(directory)
    default_branch = default_branch_name(directory)
    snapshot = collect_worktree_snapshot(directory)
    info = {
        "name": repo_name(directory),
        "path": str(directory),
        "branch": branch,
        "default_branch": default_branch,
        "off_mainline": not is_mainline_branch(branch),
        "remote_url": origin_url(directory),
        "dirty": snapshot.dirty,
        "tracked_change_count": 0,
        "untracked_change_count": 0,
        "generated_untracked_count": 0,
        "tracked_changes_sample": [],
        "untracked_changes_sample": [],
        "generated_untracked_sample": [],
        "ahead": 0,
        "behind": 0,
        "last_action": "checked",
        "last_sync_at": iso_now(),
        "last_pull_at": None,
    }
    apply_worktree_snapshot(info, snapshot)
    problems: list[dict[str, Any]] = []
    actions: list[str] = []

    if info["dirty"]:
        observed_local_change_at = iso_now()

    if info["branch"] == "HEAD":
        problems.append(problem_entry(directory, "Repo is in a detached HEAD state.", "Check out a branch before automatic syncing can continue."))
        return RepoOutcome(info=info, problems=problems)

    if info["off_mainline"]:
        if should_pull and has_origin_remote(directory):
            ok, fetch_problem, fetch_actions = fetch_origin_with_recovery(directory, config, info["branch"])
            info["remote_url"] = origin_url(directory)
            if ok:
                actions.extend(fetch_actions)
                info["last_pull_at"] = iso_now()
            elif fetch_problem:
                actions.extend(fetch_actions)
                problems.append(fetch_problem)

        upstream = upstream_name(directory)
        ahead, behind = ahead_behind(directory, upstream)
        info["ahead"] = ahead
        info["behind"] = behind
        info["last_action"] = "off-mainline branch"
        info["last_sync_at"] = iso_now()
        if observed_local_change_at:
            info["_observed_local_change_at"] = observed_local_change_at
        return RepoOutcome(info=info, problems=problems)

    if not has_origin_remote(directory):
        ok, remote_problem, action = ensure_origin_remote(directory, config, info["branch"])
        info["remote_url"] = origin_url(directory)
        if action:
            actions.append(action)
        if not ok:
            if remote_problem:
                problems.append(remote_problem)
            info["last_action"] = ", ".join(actions) if actions else "needs origin remote"
            return RepoOutcome(info=info, problems=problems)

    committed = False
    if info["dirty"]:
        try:
            committed, _message = commit_all_changes(directory)
        except RuntimeError as error:
            problems.append(problem_entry(directory, "Auto-commit failed.", str(error)))

        if committed:
            actions.append("committed")
            apply_worktree_snapshot(info, collect_worktree_snapshot(directory))

    if should_pull and has_origin_remote(directory):
        ok, fetch_problem, fetch_actions = fetch_origin_with_recovery(directory, config, info["branch"])
        info["remote_url"] = origin_url(directory)
        if ok:
            actions.extend(fetch_actions)
            info["last_pull_at"] = iso_now()
        elif fetch_problem:
            actions.extend(fetch_actions)
            problems.append(fetch_problem)

    upstream = upstream_name(directory)
    if upstream is None and has_origin_remote(directory):
        if remote_branch_exists(directory, info["branch"]):
            linked, link_error = set_upstream_to_origin(directory, info["branch"])
            if linked:
                actions.append("linked upstream")
            elif link_error:
                problems.append(problem_entry(directory, "Linking the upstream branch failed.", link_error))
        elif has_commits(directory):
            pushed, push_error = push_branch(directory, info["branch"], set_upstream=True)
            if pushed:
                actions.append("set upstream")
            elif push_error:
                problems.append(problem_entry(directory, "Setting the upstream branch failed.", push_error))
        else:
            problems.append(
                problem_entry(
                    directory,
                    "Repo has no commits yet.",
                    "Add the first commit manually or remove this empty repo skeleton from the tracked tree.",
                    severity="warning",
                )
            )

    upstream = upstream_name(directory)
    ahead, behind = ahead_behind(directory, upstream)
    info["ahead"] = ahead
    info["behind"] = behind
    apply_worktree_snapshot(info, collect_worktree_snapshot(directory))

    if should_pull and upstream and behind > 0 and not info["dirty"]:
        if ahead == 0:
            ok, error_text = pull_fast_forward(directory)
            if ok:
                actions.append("pulled")
                info["last_pull_at"] = iso_now()
            else:
                problems.append(problem_entry(directory, "Fast-forward pull failed.", error_text))
        elif config.get("auto_rebase_divergent_repos", True):
            ok, error_text = pull_rebase(directory)
            if ok:
                actions.append("rebased")
                info["last_pull_at"] = iso_now()
            else:
                problems.append(problem_entry(directory, "Auto-rebase failed.", error_text))
        else:
            problems.append(
                problem_entry(
                    directory,
                    "Repo has diverged from origin.",
                    "Enable auto_rebase_divergent_repos or resolve the rebase manually.",
                )
            )

        upstream = upstream_name(directory)
        ahead, behind = ahead_behind(directory, upstream)
        info["ahead"] = ahead
        info["behind"] = behind

    if has_origin_remote(directory):
        upstream = upstream_name(directory)
        ahead, behind = ahead_behind(directory, upstream)
        info["ahead"] = ahead
        info["behind"] = behind

        if behind == 0 and ahead > 0:
            pushed, push_error = push_branch(directory, info["branch"], set_upstream=upstream is None)
            if pushed:
                actions.append("pushed")
                upstream = upstream_name(directory)
                ahead, behind = ahead_behind(directory, upstream)
                info["ahead"] = ahead
                info["behind"] = behind
            elif push_error and config.get("auto_rebase_divergent_repos", True) and not repo_dirty(directory) and should_retry_after_push_rejection(push_error):
                fetched, fetch_error = fetch_origin(directory)
                if fetched:
                    actions.append("fetched")
                    rebased, rebase_error = pull_rebase(directory)
                    if rebased:
                        actions.append("rebased")
                        pushed, second_push_error = push_branch(directory, info["branch"], set_upstream=False)
                        if pushed:
                            actions.append("pushed")
                            upstream = upstream_name(directory)
                            ahead, behind = ahead_behind(directory, upstream)
                            info["ahead"] = ahead
                            info["behind"] = behind
                        elif second_push_error:
                            problems.append(problem_entry(directory, "Pushing changes failed.", second_push_error))
                    elif rebase_error:
                        problems.append(problem_entry(directory, "Auto-rebase failed after push rejection.", rebase_error))
                elif fetch_error:
                    problems.append(problem_entry(directory, "Fetching remote changes failed after push rejection.", fetch_error))
            elif push_error:
                problems.append(problem_entry(directory, "Pushing changes failed.", push_error))

    if info["ahead"] > 0 and info["behind"] > 0:
        problems.append(problem_entry(directory, "Repo still diverges from origin.", "Review the repo manually; automatic rebase was not enough."))

    info["last_action"] = ", ".join(actions) if actions else "checked"
    info["last_sync_at"] = iso_now()
    info["remote_url"] = origin_url(directory)
    apply_worktree_snapshot(info, collect_worktree_snapshot(directory))
    if observed_local_change_at:
        info["_observed_local_change_at"] = observed_local_change_at
    return RepoOutcome(info=info, problems=problems)


def render_problem_report(status: dict[str, Any]) -> str:
    lines = [
        "Gitter Problems Report",
        "======================",
        "",
        f"Generated: {format_timestamp(status.get('generated_at'))}",
        f"Root path: {status.get('root_path', '')}",
        f"Tracked repos: {status.get('tracked_repo_count', 0)}",
        f"Problem repos: {status.get('problem_repo_count', 0)}",
        "",
    ]

    problems = status.get("problems", [])
    if not problems:
        lines.append("No current problems.")
        return "\n".join(lines) + "\n"

    for index, problem in enumerate(problems, start=1):
        lines.extend(
            [
                f"{index}. {problem.get('repo_name', 'unknown')}",
                f"   Path: {problem.get('path', '')}",
                f"   Severity: {problem.get('severity', 'error')}",
                f"   Issue: {problem.get('message', '')}",
                f"   Fix: {problem.get('fix_hint', '')}",
                "",
            ]
        )

    return "\n".join(lines)


def write_status(status: dict[str, Any], activity_events: list[dict[str, Any]] | None = None) -> None:
    payload = finalize_status_payload(status, activity_events=activity_events)
    payload["generated_at"] = iso_now()
    atomic_write_json(STATUS_FILE, payload)
    atomic_write_text(REPORT_FILE, render_problem_report(payload))
    status.clear()
    status.update(payload)


def build_base_status(config: dict[str, Any], cycle_number: int) -> dict[str, Any]:
    return {
        "app": "gitterd",
        "version": "3.0.0",
        "config_path": str((ROOT_DIR / "gitter.local.json").resolve()) if (ROOT_DIR / "gitter.local.json").exists() else None,
        "root_path": config["root_path"],
        "github_username": config["github_username"],
        "github_org": config["github_org"],
        "interval_seconds": config["interval_seconds"],
        "pull_every_cycles": config["pull_every_cycles"],
        "use_file_watcher": config["use_file_watcher"],
        "event_debounce_seconds": config["event_debounce_seconds"],
        "enable_new_repo_init": config["enable_new_repo_init"],
        "auto_create_missing_repos": config["auto_create_missing_repos"],
        "auto_rebase_divergent_repos": config["auto_rebase_divergent_repos"],
        "ignored_paths": list(config.get("ignored_paths", [])),
        "ignored_path_globs": list(config.get("ignored_path_globs", [])),
        "running": True,
        "paused": False,
        "scan_in_progress": False,
        "cycle_number": cycle_number,
        "tracked_repo_count": 0,
        "problem_count": 0,
        "problem_repo_count": 0,
        "new_repo_candidates": [],
        "repos": [],
        "problems": [],
        "top_attention_repos": [],
        "activity_summary": {
            "events_24h": 0,
            "events_7d": 0,
            "active_repo_count_24h": 0,
            "problem_events_24h": 0,
            "last_event_at": None,
            "last_event_summary": None,
        },
        "current_repo": None,
        "last_scan_started_at": None,
        "last_scan_completed_at": None,
        "last_successful_sync_at": None,
        "last_pull_scan_at": None,
        "last_local_event_at": None,
        "last_targeted_sync_at": None,
        "last_sync_reason": None,
        "next_scan_at": None,
        "pending_repo_count": 0,
        "watcher_enabled": False,
        "watcher_backend": "polling",
        "control_file": str(CONTROL_FILE),
        "status_file": str(STATUS_FILE),
        "problem_report_file": str(REPORT_FILE),
        "activity_file": str(ACTIVITY_FILE),
        "log_dir": str(LOG_DIR),
        "dashboard_url": dashboard_url(),
        "pid": os.getpid(),
    }


def unique_problem_repo_count(problems: list[dict[str, Any]]) -> int:
    return len({problem.get("path") for problem in problems if problem.get("path")})


def run_cycle(config: dict[str, Any], cycle_number: int, force_pull: bool = False) -> dict[str, Any]:
    state = build_runtime_state(config, config_path=None, cycle_number=cycle_number)
    run_full_reconcile(
        state,
        reason="manual run-now" if force_pull else "scheduled reconcile",
        force_pull=force_pull,
    )
    return dict(state.status)


def stop_signal_handler(_signum: int, _frame: Any) -> None:
    global STOP_REQUESTED
    STOP_REQUESTED = True
    STOP_EVENT.set()


def update_paused_status(status: dict[str, Any], paused: bool, config: dict[str, Any]) -> None:
    status["paused"] = paused
    status["running"] = True
    status["scan_in_progress"] = False
    status["next_scan_at"] = None if paused else iso_now()
    status["interval_seconds"] = config["interval_seconds"]
    status["pull_every_cycles"] = config["pull_every_cycles"]
    write_status(status)


def wait_for_next_cycle(config: dict[str, Any], status: dict[str, Any]) -> bool:
    deadline = time.time() + config["interval_seconds"]

    while time.time() < deadline and not STOP_REQUESTED:
        control = load_control()
        if control.get("run_now") or control.get("force_pull"):
            return True

        if control.get("paused"):
            update_paused_status(status, paused=True, config=config)
            while not STOP_REQUESTED:
                paused_control = load_control()
                if not paused_control.get("paused"):
                    update_paused_status(status, paused=False, config=config)
                    if paused_control.get("run_now") or paused_control.get("force_pull"):
                        return True
                    break
                time.sleep(1)

        status["next_scan_at"] = time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(deadline))
        write_status(status)
        time.sleep(1)

    return not STOP_REQUESTED


def is_internal_runtime_path(path: Path) -> bool:
    resolved = resolve_path(path)
    runtime_dir = resolve_path(STATUS_FILE.parent)
    log_dir = resolve_path(LOG_DIR)
    if resolved == resolve_path(STATUS_FILE) or resolved == resolve_path(CONTROL_FILE) or resolved == resolve_path(REPORT_FILE) or resolved == resolve_path(PID_FILE):
        return True
    return runtime_dir in resolved.parents or log_dir in resolved.parents


def is_path_within_root(path: Path, root_path: Path) -> bool:
    try:
        resolve_path(path).relative_to(resolve_path(root_path))
        return True
    except ValueError:
        return False


def has_excluded_component(path: Path, root_path: Path) -> bool:
    try:
        relative = resolve_path(path).relative_to(resolve_path(root_path))
    except ValueError:
        return False
    return any(part in EXCLUDED_DIR_NAMES for part in relative.parts)


def should_ignore_watch_path(path: Path, config: dict[str, Any], root_path: Path) -> bool:
    if is_internal_runtime_path(path):
        return True
    if path.name in {".DS_Store"} or path.name.endswith(("~", ".swp", ".swo")):
        return True
    if has_excluded_component(path, root_path):
        return True
    return is_ignored_path(path, config)


def find_tracked_repo_for_path(state: RuntimeState, path: Path) -> Path | None:
    current = resolve_path(path)
    if not current.is_dir():
        current = current.parent

    root_path = resolve_path(state.root_path)
    while True:
        key = str(current)
        if key in state.tracked_repo_keys:
            return current
        if current == root_path or current.parent == current:
            return None
        current = current.parent


def path_requires_full_reconcile(state: RuntimeState, path: Path) -> bool:
    resolved = resolve_path(path)
    try:
        relative = resolved.relative_to(resolve_path(state.root_path))
    except ValueError:
        return False

    if not relative.parts:
        return False

    top_level = state.root_path / relative.parts[0]
    if top_level.name in EXCLUDED_DIR_NAMES or is_ignored_path(top_level, state.config):
        return False
    if path.name == ".gitter-ignore":
        return True
    if not top_level.exists():
        return True
    return top_level.is_dir()


def collect_changed_repos(state: RuntimeState, changes: set[tuple[Any, str]]) -> tuple[list[Path], bool]:
    changed_repo_keys: set[str] = set()
    needs_full_reconcile = False

    for _change, raw_path in changes:
        changed_path = Path(raw_path)
        if should_ignore_watch_path(changed_path, state.config, state.root_path):
            continue

        repo = find_tracked_repo_for_path(state, changed_path)
        if repo is not None:
            changed_repo_keys.add(str(repo))
            continue

        if is_path_within_root(changed_path, state.root_path) and path_requires_full_reconcile(state, changed_path):
            needs_full_reconcile = True

    return [Path(key) for key in sorted(changed_repo_keys)], needs_full_reconcile


def run_full_reconcile(state: RuntimeState, reason: str, force_pull: bool = False) -> None:
    pull_due = force_pull or state.next_cycle_number == 1 or state.next_cycle_number % state.config["pull_every_cycles"] == 0
    started_at = iso_now()

    state.pending_repos.clear()
    state.status["cycle_number"] = state.next_cycle_number
    state.status["scan_in_progress"] = True
    state.status["current_repo"] = None
    state.status["paused"] = False
    state.status["next_scan_at"] = None
    state.status["last_scan_started_at"] = started_at
    state.status["last_sync_reason"] = reason + (" (forced remote sync)" if force_pull else "")
    if pull_due:
        state.status["last_pull_scan_at"] = started_at

    if not state.root_path.is_dir():
        set_tracked_repos(state, [])
        state.init_candidates = []
        state.repo_info_by_path.clear()
        state.problems_by_path = {
            status_path_key(state.root_path): [
                {
                    "repo_name": "root",
                    "path": str(state.root_path),
                    "severity": "error",
                    "message": "The configured root path does not exist.",
                    "fix_hint": "Update gitter.local.json or pass --root with the correct repository root.",
                }
            ]
        }
        state.status["scan_in_progress"] = False
        state.status["last_scan_completed_at"] = iso_now()
        write_runtime_state(state)
        state.next_cycle_number += 1
        return

    state.problems_by_path.pop(status_path_key(state.root_path), None)
    write_runtime_state(state)

    repos, init_candidates = scan_directories(state.root_path, state.config)
    state.init_candidates = init_candidates
    log_reason = reason + ("; forced remote sync" if force_pull else "")
    log("INFO", f"Starting reconcile #{state.next_cycle_number}: {len(repos)} tracked repos, {len(init_candidates)} init candidates ({log_reason})")

    initialized_paths: list[Path] = []
    initialized_keys: set[str] = set()
    transient_problem_keys: set[str] = set()
    if state.config["enable_new_repo_init"]:
        for directory in init_candidates:
            if STOP_REQUESTED:
                break

            state.status["current_repo"] = str(directory)
            write_runtime_state(state)
            repo_info, problems = initialize_repo(directory, state.config)
            if (directory / ".git").is_dir():
                set_repo_snapshot(state, repo_info, problems)
                initialized_paths.append(directory)
                initialized_keys.add(status_path_key(directory))
            else:
                transient_problem_keys.add(status_path_key(directory))
                set_path_problems(state, directory, problems)

    set_tracked_repos(state, [*repos, *initialized_paths])

    for index, directory in enumerate(state.tracked_repos, start=1):
        if STOP_REQUESTED:
            break
        if status_path_key(directory) in initialized_keys:
            continue

        state.status["current_repo"] = str(directory)
        write_runtime_state(state)
        log("INFO", f"Processing {index}/{len(state.tracked_repos)}: {directory}")
        outcome = process_repo(directory, state.config, should_pull=pull_due)
        set_repo_snapshot(state, outcome.info, outcome.problems)

    allowed_problem_keys = set(state.tracked_repo_keys) | transient_problem_keys
    for key in list(state.problems_by_path):
        if key not in allowed_problem_keys:
            state.problems_by_path.pop(key, None)

    completed_at = iso_now()
    state.status["scan_in_progress"] = False
    state.status["current_repo"] = None
    state.status["last_scan_completed_at"] = completed_at
    state.status["last_successful_sync_at"] = completed_at
    write_runtime_state(state)

    log(
        "INFO",
        f"Completed reconcile #{state.status['cycle_number']}: {state.status['tracked_repo_count']} repos, {state.status['problem_repo_count']} repos with problems",
    )
    state.next_cycle_number += 1


def run_targeted_sync(state: RuntimeState, repos: list[Path], reason: str) -> None:
    if not repos:
        return

    if "filesystem" in reason.lower():
        record_activity_entries(
            state,
            [activity_event(repo, repo.name, "filesystem_change", "Local filesystem change detected", severity="info") for repo in repos],
        )

    changed_keys = {status_path_key(repo) for repo in repos}
    state.pending_repos = set(changed_keys)
    state.status["scan_in_progress"] = True
    state.status["current_repo"] = None
    state.status["paused"] = False
    state.status["last_sync_reason"] = reason
    write_runtime_state(state)

    log("INFO", f"Starting targeted sync for {len(repos)} repos ({reason})")
    for index, directory in enumerate(repos, start=1):
        if STOP_REQUESTED:
            break
        if status_path_key(directory) not in state.tracked_repo_keys:
            continue

        state.status["current_repo"] = str(directory)
        write_runtime_state(state)
        log("INFO", f"Processing changed repo {index}/{len(repos)}: {directory}")
        outcome = process_repo(directory, state.config, should_pull=False)
        set_repo_snapshot(state, outcome.info, outcome.problems)

    completed_at = iso_now()
    state.pending_repos.clear()
    state.status["scan_in_progress"] = False
    state.status["current_repo"] = None
    state.status["last_targeted_sync_at"] = completed_at
    state.status["last_successful_sync_at"] = completed_at
    write_runtime_state(state)
    log("INFO", f"Completed targeted sync for {len(repos)} repos ({reason})")


def consume_run_now_request() -> bool:
    control = load_control()
    force_pull = bool(control.get("force_pull"))
    if control.get("run_now") or force_pull:
        control["run_now"] = False
        control["force_pull"] = False
        save_control(control)
        return force_pull
    return False


def run_watch_mode(state: RuntimeState) -> dict[str, Any]:
    debounce_ms = max(200, int(float(state.config["event_debounce_seconds"]) * 1000))
    next_reconcile_deadline = time.time() + state.config["interval_seconds"]
    paused = False
    resume_requires_reconcile = False

    watch_filter = lambda _change, raw_path: not should_ignore_watch_path(Path(raw_path), state.config, state.root_path)

    for changes in watch(
        str(state.root_path),
        watch_filter=watch_filter,
        debounce=debounce_ms,
        step=50,
        stop_event=STOP_EVENT,
        rust_timeout=1000,
        yield_on_timeout=True,
        recursive=True,
        ignore_permission_denied=True,
    ):
        if STOP_REQUESTED:
            break

        control = load_control()
        if control.get("paused"):
            if not paused:
                paused = True
                update_paused_status(state.status, paused=True, config=state.config)
            resume_requires_reconcile = True
            continue

        if paused:
            paused = False
            update_paused_status(state.status, paused=False, config=state.config)
            next_reconcile_deadline = time.time()

        reconcile_reason: str | None = None
        force_pull = False
        if control.get("run_now") or control.get("force_pull"):
            force_pull = consume_run_now_request()
            reconcile_reason = "manual run-now"
        elif resume_requires_reconcile:
            reconcile_reason = "resume reconcile"
        elif time.time() >= next_reconcile_deadline:
            reconcile_reason = "scheduled reconcile"

        changed_repos: list[Path] = []
        if changes:
            state.status["last_local_event_at"] = iso_now()
            changed_repos, needs_full_reconcile = collect_changed_repos(state, changes)
            if needs_full_reconcile and reconcile_reason is None:
                reconcile_reason = "filesystem discovery event"

        if reconcile_reason is not None:
            resume_requires_reconcile = False
            run_full_reconcile(state, reason=reconcile_reason, force_pull=force_pull)
            next_reconcile_deadline = time.time() + state.config["interval_seconds"]
            state.status["next_scan_at"] = format_deadline(next_reconcile_deadline)
            write_runtime_state(state)
            continue

        if changed_repos:
            run_targeted_sync(state, changed_repos, reason="filesystem event")

        state.status["next_scan_at"] = format_deadline(next_reconcile_deadline)
        write_runtime_state(state)

    return state.status


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Continuously sync Git repositories and expose status for a menu bar app.")
    parser.add_argument("--config", help="Path to a local gitter config JSON file.")
    parser.add_argument("--root", dest="root_path", help="Root directory to scan for git repositories.")
    parser.add_argument("--github-username", dest="github_username", help="GitHub username to use for missing remotes.")
    parser.add_argument("--github-org", dest="github_org", help="GitHub organization to use instead of the personal username.")
    parser.add_argument("--interval-seconds", dest="interval_seconds", type=int, help="Seconds between full sync cycles.")
    parser.add_argument("--pull-every-cycles", dest="pull_every_cycles", type=int, help="How many cycles to wait between remote fetch/pull scans.")
    parser.add_argument("--disable-watch", dest="use_file_watcher", action="store_false", default=None, help="Disable macOS file watching and use timer-based polling only.")
    parser.add_argument("--enable-new-repo-init", dest="enable_new_repo_init", action="store_true", help="Allow top-level non-git project directories to be initialized.")
    parser.add_argument("--disable-auto-create-missing-repos", dest="auto_create_missing_repos", action="store_false", default=None, help="Never create GitHub repos for missing origins.")
    parser.add_argument("--once", action="store_true", help="Run a single sync cycle and exit.")
    return parser.parse_args()


def main() -> int:
    ensure_runtime_dirs()
    signal.signal(signal.SIGTERM, stop_signal_handler)
    signal.signal(signal.SIGINT, stop_signal_handler)

    args = parse_args()
    overrides = {
        "root_path": args.root_path,
        "github_username": args.github_username,
        "github_org": args.github_org,
        "interval_seconds": args.interval_seconds,
        "pull_every_cycles": args.pull_every_cycles,
        "use_file_watcher": args.use_file_watcher,
        "enable_new_repo_init": True if args.enable_new_repo_init else None,
        "auto_create_missing_repos": args.auto_create_missing_repos,
    }
    config, config_path = load_config(args.config, overrides=overrides)

    previous_status = load_json(STATUS_FILE, {})
    cycle_number = int(previous_status.get("cycle_number", 0)) + 1 if isinstance(previous_status, dict) and previous_status else 1

    state = build_runtime_state(config, config_path, cycle_number)
    write_runtime_state(state)
    status = state.status
    atomic_write_text(PID_FILE, f"{os.getpid()}\n")
    exit_code = 0
    control_server = None
    control_thread = None

    try:
        control_server, control_thread = start_control_plane(repo_root=ROOT_DIR, logger=log)
    except OSError as error:
        log("ERROR", f"Control plane failed to start: {error}")

    try:
        control = load_control()
        if control.get("paused"):
            update_paused_status(state.status, paused=True, config=config)
            while not STOP_REQUESTED:
                paused_control = load_control()
                if not paused_control.get("paused"):
                    update_paused_status(state.status, paused=False, config=config)
                    break
                time.sleep(1)

        startup_force_pull = consume_run_now_request()
        run_full_reconcile(state, reason="startup", force_pull=startup_force_pull)
        status = state.status

        if state.watcher_enabled:
            if not args.once and not STOP_REQUESTED:
                status = run_watch_mode(state)
        else:
            while not args.once and not STOP_REQUESTED:
                if not wait_for_next_cycle(config, state.status):
                    break
                force_pull = consume_run_now_request()
                run_full_reconcile(
                    state,
                    reason="manual run-now" if force_pull else "scheduled reconcile",
                    force_pull=force_pull,
                )
                status = state.status
    finally:
        status["running"] = False
        status["scan_in_progress"] = False
        status["current_repo"] = None
        status["next_scan_at"] = None
        write_status(status, activity_events=state.activity_log)
        stop_control_plane(control_server, control_thread)
        if PID_FILE.exists():
            PID_FILE.unlink(missing_ok=True)

    return exit_code


if __name__ == "__main__":
    sys.exit(main())
