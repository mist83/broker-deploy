from __future__ import annotations

import getpass
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT_DIR = Path(__file__).resolve().parent
STATE_DIR = ROOT_DIR / "runtime"
LOG_DIR = Path.home() / "Library" / "Logs" / "Gitter"
STATUS_FILE = STATE_DIR / "status.json"
CONTROL_FILE = STATE_DIR / "control.json"
REPORT_FILE = STATE_DIR / "problems.txt"
PID_FILE = STATE_DIR / "gitterd.pid"
ACTIVITY_FILE = STATE_DIR / "activity.jsonl"
DEFAULT_CONFIG_PATH = ROOT_DIR / "gitter.local.json"

EXCLUDED_DIR_NAMES = {
    ".git",
    ".svn",
    ".hg",
    ".idea",
    ".vscode",
    ".vs",
    ".env",
    ".next",
    ".nuxt",
    ".cache",
    ".parcel-cache",
    ".serverless",
    ".terraform",
    ".yarn",
    "bin",
    "build",
    "dist",
    "node_modules",
    "obj",
    "old",
    "tmp",
    "temp",
}

PROJECT_MARKERS = (
    ".gitter-init",
    "package.json",
    "pyproject.toml",
    "requirements.txt",
    "Cargo.toml",
    "go.mod",
    "Gemfile",
    "composer.json",
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    "Makefile",
    "Dockerfile",
)

DEFAULT_CONFIG = {
    "root_path": str((Path.home() / "Code").resolve()),
    "github_username": getpass.getuser(),
    "github_org": "",
    "interval_seconds": 300,
    "pull_every_cycles": 6,
    "use_file_watcher": True,
    "event_debounce_seconds": 2.0,
    "enable_new_repo_init": False,
    "auto_create_missing_repos": True,
    "auto_rebase_divergent_repos": True,
    "repo_visibility": "private",
    "ignored_paths": [],
    "ignored_path_globs": [],
    "max_problem_repos": 12,
}

CONFIG_KEYS = tuple(DEFAULT_CONFIG.keys())


def _int_from_env(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default

    try:
        return int(raw)
    except ValueError:
        return default


CONTROL_PLANE_HOST = os.environ.get("GITTER_CONTROL_HOST", "127.0.0.1").strip() or "127.0.0.1"
CONTROL_PLANE_PORT = _int_from_env("GITTER_CONTROL_PORT", 9477)


def iso_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def ensure_runtime_dirs() -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    STATE_DIR.mkdir(parents=True, exist_ok=True)


def atomic_write_text(path: Path, text: str) -> None:
    ensure_runtime_dirs()
    path.parent.mkdir(parents=True, exist_ok=True)

    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def atomic_write_json(path: Path, payload: Any) -> None:
    atomic_write_text(path, json.dumps(payload, indent=2, sort_keys=False) + "\n")


def load_json(path: Path, default: Any) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except json.JSONDecodeError:
        return default


def parse_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None

    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def control_plane_origin(host: str | None = None, port: int | None = None) -> str:
    resolved_host = (host or CONTROL_PLANE_HOST).strip() or "127.0.0.1"
    resolved_port = int(port if port is not None else CONTROL_PLANE_PORT)
    return f"http://{resolved_host}:{resolved_port}"


def dashboard_url(host: str | None = None, port: int | None = None) -> str:
    return control_plane_origin(host=host, port=port) + "/"


def resolve_config_path(explicit_path: str | None = None) -> Path | None:
    if explicit_path:
        return Path(explicit_path).expanduser()

    if DEFAULT_CONFIG_PATH.exists():
        return DEFAULT_CONFIG_PATH

    fallback = ROOT_DIR / "gitter.json"
    if fallback.exists():
        return fallback

    return None


def load_config(explicit_path: str | None = None, overrides: dict[str, Any] | None = None) -> tuple[dict[str, Any], Path | None]:
    config = dict(DEFAULT_CONFIG)
    config_path = resolve_config_path(explicit_path)

    if config_path and config_path.exists():
        loaded = load_json(config_path, {})
        if isinstance(loaded, dict):
            config.update(loaded)

    if overrides:
        for key, value in overrides.items():
            if value is not None:
                config[key] = value

    config["root_path"] = str(Path(str(config["root_path"])).expanduser())
    config["interval_seconds"] = max(30, int(config["interval_seconds"]))
    config["pull_every_cycles"] = max(1, int(config["pull_every_cycles"]))
    config["use_file_watcher"] = bool(config.get("use_file_watcher", True))
    config["event_debounce_seconds"] = max(0.2, float(config.get("event_debounce_seconds", 2.0)))
    config["enable_new_repo_init"] = bool(config["enable_new_repo_init"])
    config["auto_create_missing_repos"] = bool(config["auto_create_missing_repos"])
    config["auto_rebase_divergent_repos"] = bool(config.get("auto_rebase_divergent_repos", True))
    config["max_problem_repos"] = max(1, int(config["max_problem_repos"]))
    config["github_username"] = str(config.get("github_username", "")).strip()
    config["github_org"] = str(config.get("github_org", "")).strip()
    config["repo_visibility"] = str(config.get("repo_visibility", "private")).strip() or "private"
    config["ignored_paths"] = [str(value).strip() for value in config.get("ignored_paths", []) if str(value).strip()]
    config["ignored_path_globs"] = [str(value).strip() for value in config.get("ignored_path_globs", []) if str(value).strip()]

    return config, config_path


def config_for_save(config: dict[str, Any]) -> dict[str, Any]:
    saved: dict[str, Any] = {}
    for key in CONFIG_KEYS:
        if key not in config:
            continue
        value = config[key]
        if isinstance(value, Path):
            saved[key] = str(value)
        else:
            saved[key] = value
    return saved


def save_config(config: dict[str, Any], explicit_path: str | Path | None = None) -> Path:
    if explicit_path is None:
        target_path = resolve_config_path() or DEFAULT_CONFIG_PATH
    else:
        target_path = Path(explicit_path).expanduser()

    target_path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_json(target_path, config_for_save(config))
    return target_path


def default_control_state() -> dict[str, Any]:
    return {
        "paused": False,
        "run_now": False,
        "force_pull": False,
        "updated_at": iso_now(),
    }


def load_control() -> dict[str, Any]:
    control = load_json(CONTROL_FILE, default_control_state())
    if not isinstance(control, dict):
        control = default_control_state()

    control.setdefault("paused", False)
    control.setdefault("run_now", False)
    control.setdefault("force_pull", False)
    control.setdefault("updated_at", iso_now())
    return control


def save_control(control: dict[str, Any]) -> None:
    payload = default_control_state()
    payload.update(control)
    payload["updated_at"] = iso_now()
    atomic_write_json(CONTROL_FILE, payload)


def format_timestamp(value: str | None) -> str:
    if not value:
        return "never"

    parsed = parse_timestamp(value)
    if not parsed:
        return value

    return parsed.astimezone().strftime("%Y-%m-%d %H:%M:%S")
