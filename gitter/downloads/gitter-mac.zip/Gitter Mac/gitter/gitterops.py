from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from gitterlib import ACTIVITY_FILE, atomic_write_text, dashboard_url, ensure_runtime_dirs, iso_now, parse_timestamp


SEVERITY_ORDER = {
    "error": 3,
    "warning": 2,
    "info": 1,
}

LOCAL_CHANGE_KINDS = {
    "filesystem_change",
    "repo_initialized",
}


def is_new_repo_action(last_action: str | None) -> bool:
    action = str(last_action or "").strip().lower()
    return action.startswith("initialized") or action == "new repo detected"


def is_missing_origin_remote_problem(problem: dict[str, Any] | None) -> bool:
    if not problem:
        return False
    message = str(problem.get("message") or "").strip().lower()
    return message in {
        "repo has no origin remote.",
        "repo has no usable origin remote.",
    }


def normalize_severity(value: str | None) -> str:
    lowered = str(value or "error").strip().lower()
    if lowered in SEVERITY_ORDER:
        return lowered
    return "error"


def severity_rank(value: str | None) -> int:
    return SEVERITY_ORDER.get(normalize_severity(value), 0)


def problem_sort_key(problem: dict[str, Any]) -> tuple[int, str, str]:
    return (
        -severity_rank(problem.get("severity")),
        str(problem.get("repo_name", "")).lower(),
        str(problem.get("message", "")).lower(),
    )


def sort_problems(problems: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted((dict(problem) for problem in problems if isinstance(problem, dict)), key=problem_sort_key)


def load_activity_events(path: Path | None = None) -> list[dict[str, Any]]:
    target = path or ACTIVITY_FILE
    try:
        text = target.read_text(encoding="utf-8")
    except FileNotFoundError:
        return []

    events: list[dict[str, Any]] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            events.append(normalize_activity_event(payload))
    return sorted(events, key=activity_timestamp_key)


def activity_timestamp_key(event: dict[str, Any]) -> tuple[float, str]:
    parsed = parse_timestamp(str(event.get("timestamp") or "")) or datetime.fromtimestamp(0, tz=timezone.utc)
    return parsed.timestamp(), str(event.get("summary", ""))


def prune_activity_events(
    events: Iterable[dict[str, Any]],
    now: datetime | None = None,
    retain_days: int = 30,
) -> list[dict[str, Any]]:
    cutoff = (now or datetime.now(timezone.utc)) - timedelta(days=retain_days)
    retained: list[dict[str, Any]] = []
    for event in events:
        parsed = parse_timestamp(str(event.get("timestamp") or ""))
        if parsed is not None and parsed >= cutoff:
            retained.append(normalize_activity_event(event))
    return sorted(retained, key=activity_timestamp_key)


def write_activity_events(events: Iterable[dict[str, Any]], path: Path | None = None) -> list[dict[str, Any]]:
    target = path or ACTIVITY_FILE
    ensure_runtime_dirs()
    payload = prune_activity_events(events)
    lines = [json.dumps(event, sort_keys=False) for event in payload]
    atomic_write_text(target, ("\n".join(lines) + "\n") if lines else "")
    return payload


def append_activity_events(
    entries: Iterable[dict[str, Any]],
    existing_events: list[dict[str, Any]] | None = None,
    path: Path | None = None,
) -> list[dict[str, Any]]:
    current = list(existing_events) if existing_events is not None else load_activity_events(path=path)
    for entry in entries:
        if isinstance(entry, dict):
            current.append(normalize_activity_event(entry))
    return write_activity_events(current, path=path)


def normalize_activity_event(event: dict[str, Any]) -> dict[str, Any]:
    payload = dict(event)
    payload["timestamp"] = str(payload.get("timestamp") or iso_now())
    payload["kind"] = str(payload.get("kind") or "note").strip() or "note"
    payload["summary"] = str(payload.get("summary") or payload["kind"]).strip() or payload["kind"]
    payload["repo_name"] = str(payload.get("repo_name") or "").strip()
    payload["path"] = str(payload.get("path") or "").strip()
    payload["severity"] = normalize_severity(str(payload.get("severity") or "info"))
    return payload


def recent_activity_for_repo(
    path: str | Path,
    activity_events: Iterable[dict[str, Any]],
    now: datetime | None = None,
    limit: int = 5,
) -> dict[str, Any]:
    repo_path = str(Path(path))
    current_time = now or datetime.now(timezone.utc)
    seven_days_ago = current_time - timedelta(days=7)
    repo_events = [normalize_activity_event(event) for event in activity_events if str(event.get("path") or "") == repo_path]
    repo_events.sort(key=activity_timestamp_key, reverse=True)

    daily_counts = [0, 0, 0, 0, 0, 0, 0]
    last_event_at: str | None = None
    last_event_kind: str | None = None
    last_event_summary: str | None = None
    last_local_change_at: str | None = None
    recent_items: list[dict[str, Any]] = []
    event_count_7d = 0

    for event in repo_events:
        parsed = parse_timestamp(event.get("timestamp"))
        if parsed is not None and parsed > current_time:
            parsed = current_time

        if last_event_at is None:
            last_event_at = event.get("timestamp")
            last_event_kind = event.get("kind")
            last_event_summary = event.get("summary")

        if last_local_change_at is None and is_local_change_event(event):
            last_local_change_at = event.get("timestamp")

        if len(recent_items) < limit:
            recent_items.append(
                {
                    "at": event.get("timestamp"),
                    "kind": event.get("kind"),
                    "summary": event.get("summary"),
                    "severity": event.get("severity"),
                }
            )

        if parsed is None or parsed < seven_days_ago:
            continue

        event_count_7d += 1
        day_index = (current_time.date() - parsed.date()).days
        if 0 <= day_index < 7:
            daily_counts[6 - day_index] += 1

    return {
        "event_count_7d": event_count_7d,
        "events_7d": daily_counts,
        "last_event_at": last_event_at,
        "last_event_kind": last_event_kind,
        "last_event_summary": last_event_summary,
        "last_local_change_at": last_local_change_at,
        "recent_items": recent_items,
    }


def build_activity_summary(activity_events: Iterable[dict[str, Any]], now: datetime | None = None) -> dict[str, Any]:
    current_time = now or datetime.now(timezone.utc)
    day_ago = current_time - timedelta(days=1)
    week_ago = current_time - timedelta(days=7)

    events_24h = 0
    events_7d = 0
    problem_events_24h = 0
    active_repos_24h: set[str] = set()
    last_event_at: str | None = None
    last_event_summary: str | None = None

    normalized = [normalize_activity_event(event) for event in activity_events]
    normalized.sort(key=activity_timestamp_key, reverse=True)

    for index, event in enumerate(normalized):
        parsed = parse_timestamp(event.get("timestamp"))
        if parsed is None:
            continue

        if index == 0:
            last_event_at = event.get("timestamp")
            last_event_summary = event.get("summary")

        if parsed >= week_ago:
            events_7d += 1

        if parsed < day_ago:
            continue

        events_24h += 1
        if event.get("path"):
            active_repos_24h.add(str(event.get("path")))
        if str(event.get("kind")) == "problem_detected":
            problem_events_24h += 1

    return {
        "events_24h": events_24h,
        "events_7d": events_7d,
        "active_repo_count_24h": len(active_repos_24h),
        "problem_events_24h": problem_events_24h,
        "last_event_at": last_event_at,
        "last_event_summary": last_event_summary,
    }


def max_timestamp(*values: str | None) -> str | None:
    best_value: str | None = None
    best_parsed: datetime | None = None

    for value in values:
        parsed = parse_timestamp(value)
        if parsed is None:
            continue
        if best_parsed is None or parsed > best_parsed:
            best_parsed = parsed
            best_value = value

    return best_value


def highest_problem(problems: Iterable[dict[str, Any]]) -> dict[str, Any] | None:
    sorted_problems = sort_problems(problems)
    return sorted_problems[0] if sorted_problems else None


def derive_protection_state(info: dict[str, Any], problems: list[dict[str, Any]]) -> str:
    if problems:
        return "blocked"
    if info.get("off_mainline"):
        return "off-mainline"
    if info.get("dirty"):
        return "dirty"
    ahead = int(info.get("ahead", 0) or 0)
    behind = int(info.get("behind", 0) or 0)
    if ahead > 0 and behind > 0:
        return "diverged"
    if behind > 0:
        return "behind"
    if ahead > 0:
        return "ahead"
    if is_new_repo_action(info.get("last_action")):
        return "new"
    return "protected"


def is_local_change_event(event: dict[str, Any]) -> bool:
    kind = str(event.get("kind") or "")
    if kind in LOCAL_CHANGE_KINDS:
        return True
    if kind == "sync_action":
        summary = str(event.get("summary") or "").lower()
        return "committed" in summary or "initialized" in summary
    return False


def avatar_url_for_remote(remote_url: str | None) -> str | None:
    remote = str(remote_url or "").strip()
    if not remote:
        return None

    owner = ""
    if remote.startswith("git@github.com:"):
        parts = remote.split(":", 1)[1].split("/")
        if len(parts) >= 2:
            owner = parts[0].strip()
    elif "github.com/" in remote:
        tail = remote.split("github.com/", 1)[1]
        parts = tail.split("/")
        if len(parts) >= 2:
            owner = parts[0].strip()

    if not owner:
        return None

    return f"https://github.com/{owner}.png?size=96"


def score_attention(
    info: dict[str, Any],
    problems: list[dict[str, Any]],
    interval_seconds: int,
    now: datetime | None = None,
) -> tuple[int, str]:
    current_time = now or datetime.now(timezone.utc)
    weighted_reasons: list[tuple[int, str]] = []

    top_problem = highest_problem(problems)
    if top_problem:
        severity = normalize_severity(top_problem.get("severity"))
        if severity == "error" and is_new_repo_action(info.get("last_action")) and is_missing_origin_remote_problem(top_problem):
            weighted_reasons.append((245, "New repo needs origin remote"))
        elif severity == "error":
            weighted_reasons.append((240, "Active error blocks protection"))
        elif severity == "warning":
            weighted_reasons.append((150, "Warning needs review"))
        else:
            weighted_reasons.append((80, "Recent issue needs review"))

    ahead = int(info.get("ahead", 0) or 0)
    behind = int(info.get("behind", 0) or 0)
    if ahead > 0 and behind > 0:
        weighted_reasons.append((120 + min(40, (ahead + behind) * 4), "Repo diverges from origin"))
    elif behind > 0:
        weighted_reasons.append((85 + min(35, behind * 4), "Remote changes are waiting"))
    elif ahead > 0:
        weighted_reasons.append((40 + min(20, ahead * 3), "Local commits still need push"))

    if info.get("off_mainline"):
        weighted_reasons.append((130 if info.get("dirty") else 75, "Repo is off the mainline branch"))

    if info.get("dirty"):
        dirty_since = parse_timestamp(info.get("dirty_since_at"))
        dirty_age_hours = 0
        if dirty_since is not None:
            dirty_age_hours = max(0, int((current_time - dirty_since).total_seconds() // 3600))
        weighted_reasons.append((90 + min(40, dirty_age_hours * 3), "Local changes remain dirty"))

    last_local_change = parse_timestamp(info.get("last_local_change_at"))
    if last_local_change is not None:
        age_seconds = max(0, int((current_time - last_local_change).total_seconds()))
        if age_seconds < 3600:
            weighted_reasons.append((70, "Recently touched locally"))
        elif age_seconds < 6 * 3600:
            weighted_reasons.append((55, "Touched in the last few hours"))
        elif age_seconds < 24 * 3600:
            weighted_reasons.append((35, "Touched today"))
        elif age_seconds < 3 * 24 * 3600:
            weighted_reasons.append((15, "Touched recently"))

    last_sync = parse_timestamp(info.get("last_sync_at"))
    if last_sync is not None:
        stale_after = max(600, int(interval_seconds) * 4)
        sync_age = int((current_time - last_sync).total_seconds())
        if sync_age > stale_after:
            weighted_reasons.append((20, "Protection status is stale"))

    if is_new_repo_action(info.get("last_action")):
        weighted_reasons.append((60, "New repo needs setup"))

    if not weighted_reasons:
        return 0, "Quiet and protected"

    weighted_reasons.sort(key=lambda item: (-item[0], item[1]))
    score = sum(weight for weight, _reason in weighted_reasons)
    return score, weighted_reasons[0][1]


def enrich_repo_snapshot(
    info: dict[str, Any],
    problems: list[dict[str, Any]],
    previous_info: dict[str, Any] | None,
    activity_events: Iterable[dict[str, Any]],
    interval_seconds: int,
    now: datetime | None = None,
) -> dict[str, Any]:
    current_time = now or datetime.now(timezone.utc)
    repo = dict(info)
    prior = dict(previous_info or {})
    observed_local_change_at = repo.pop("_observed_local_change_at", None)
    recent_activity = recent_activity_for_repo(repo.get("path", ""), activity_events, now=current_time)

    repo["recent_activity"] = recent_activity
    repo["avatar_url"] = avatar_url_for_remote(repo.get("remote_url"))

    top_problem = highest_problem(problems)
    repo["problem_severity"] = normalize_severity(top_problem.get("severity") if top_problem else None) if top_problem else None
    repo["problem_summary"] = top_problem.get("message") if top_problem else None

    repo["last_local_change_at"] = max_timestamp(
        prior.get("last_local_change_at"),
        recent_activity.get("last_local_change_at"),
        observed_local_change_at,
    )

    was_dirty = bool(prior.get("dirty"))
    if repo.get("dirty"):
        repo["dirty_since_at"] = prior.get("dirty_since_at") if was_dirty else (observed_local_change_at or repo.get("last_local_change_at") or iso_now())
    else:
        repo["dirty_since_at"] = None

    if top_problem:
        if prior.get("problem_summary") == repo["problem_summary"] and prior.get("problem_severity") == repo["problem_severity"] and prior.get("last_problem_at"):
            repo["last_problem_at"] = prior.get("last_problem_at")
        else:
            repo["last_problem_at"] = iso_now()
    else:
        repo["last_problem_at"] = prior.get("last_problem_at")

    repo["protection_state"] = derive_protection_state(repo, problems)
    score, reason = score_attention(repo, problems, interval_seconds=interval_seconds, now=current_time)
    repo["attention_score"] = score
    repo["attention_reason"] = reason
    return repo


def attention_sort_key(repo: dict[str, Any]) -> tuple[int, float, str]:
    timestamps = [
        repo.get("last_problem_at"),
        repo.get("last_local_change_at"),
        repo.get("last_sync_at"),
    ]
    best_ts = max_timestamp(*timestamps)
    parsed = parse_timestamp(best_ts) or datetime.fromtimestamp(0, tz=timezone.utc)
    return (-int(repo.get("attention_score", 0) or 0), -parsed.timestamp(), str(repo.get("name", "")).lower())


def recent_touch_sort_key(repo: dict[str, Any]) -> tuple[float, str]:
    parsed = parse_timestamp(repo.get("last_local_change_at")) or datetime.fromtimestamp(0, tz=timezone.utc)
    return (-parsed.timestamp(), str(repo.get("name", "")).lower())


def finalize_status_payload(
    status: dict[str, Any],
    activity_events: list[dict[str, Any]] | None = None,
    top_attention_limit: int = 5,
) -> dict[str, Any]:
    payload = dict(status)
    events = activity_events if activity_events is not None else load_activity_events()

    raw_problems = payload.get("problems")
    problems = sort_problems(raw_problems if isinstance(raw_problems, list) else [])
    problems_by_path: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for problem in problems:
        path = str(problem.get("path") or "").strip()
        if path:
            problems_by_path[path].append(problem)

    interval_seconds = int(payload.get("interval_seconds", 300) or 300)
    repos: list[dict[str, Any]] = []
    raw_repos = payload.get("repos")
    for raw_repo in raw_repos if isinstance(raw_repos, list) else []:
        if not isinstance(raw_repo, dict) or not raw_repo.get("path"):
            continue
        repos.append(
            enrich_repo_snapshot(
                raw_repo,
                problems_by_path.get(str(raw_repo.get("path")), []),
                previous_info=raw_repo,
                activity_events=events,
                interval_seconds=interval_seconds,
            )
        )

    repos.sort(key=attention_sort_key)

    payload["repos"] = repos
    payload["problems"] = problems
    payload["top_attention_repos"] = [dict(repo) for repo in repos[:top_attention_limit]]
    payload["activity_summary"] = build_activity_summary(events)
    payload["dashboard_url"] = str(payload.get("dashboard_url") or dashboard_url())
    return payload
