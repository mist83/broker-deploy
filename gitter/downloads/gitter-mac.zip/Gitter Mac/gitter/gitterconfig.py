from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Any

from gitterlib import (
    CONFIG_KEYS,
    DEFAULT_CONFIG,
    ROOT_DIR,
    STATUS_FILE,
    load_config,
    load_json,
    resolve_config_path,
    save_config,
)


DAEMON_PLIST = Path.home() / "Library" / "LaunchAgents" / "com.mist83.gitterd.plist"


def gh_auth_summary() -> dict[str, str]:
    gh_path = shutil.which("gh")
    if not gh_path:
        return {
            "summary": "No gh CLI detected. Gitter will rely on normal Git credentials.",
            "detail": "Install and authenticate gh if you want repo creation to use GitHub CLI auth.",
        }

    result = subprocess.run(
        [gh_path, "auth", "status"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )
    if result.returncode == 0:
        return {
            "summary": "Authenticated via gh CLI.",
            "detail": "New GitHub repos can be created through the authenticated gh session.",
        }

    return {
        "summary": "gh CLI found, but auth is missing or broken.",
        "detail": (result.stdout or "").strip() or "Run `gh auth login` if you want automatic GitHub repo creation to work cleanly.",
    }


def status_payload() -> dict[str, Any]:
    status = load_json(STATUS_FILE, {})
    if not isinstance(status, dict):
        return {}

    return {
        "running": bool(status.get("running")),
        "paused": bool(status.get("paused")),
        "scan_in_progress": bool(status.get("scan_in_progress")),
        "tracked_repo_count": int(status.get("tracked_repo_count", 0) or 0),
        "problem_repo_count": int(status.get("problem_repo_count", 0) or 0),
        "last_successful_sync_at": status.get("last_successful_sync_at"),
        "current_repo": status.get("current_repo"),
    }


def config_payload() -> dict[str, Any]:
    config, config_path = load_config()
    return {
        "config": config,
        "config_path": str(config_path) if config_path else str(resolve_config_path() or ROOT_DIR / "gitter.local.json"),
        "auth": gh_auth_summary(),
        "status": status_payload(),
    }


def restart_daemon_if_managed() -> str:
    if not DAEMON_PLIST.exists():
        return "Settings saved. Restart the daemon manually if it is already running."

    result = subprocess.run(
        ["/bin/zsh", str(ROOT_DIR / "install-launchd.sh")],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )
    if result.returncode == 0:
        return "Settings saved and daemon restarted."

    output = (result.stdout or "").strip()
    if output:
        return f"Settings saved, but daemon restart failed: {output}"
    return "Settings saved, but daemon restart failed."


def validate_payload(payload: dict[str, Any]) -> dict[str, Any]:
    current_config, _ = load_config()
    config = dict(current_config or DEFAULT_CONFIG)
    for key in CONFIG_KEYS:
        if key in payload:
            config[key] = payload[key]

    normalized, _ = load_config(overrides=config)
    return normalized


def save_payload(payload: dict[str, Any]) -> dict[str, Any]:
    normalized = validate_payload(payload)
    saved_path = save_config(normalized)
    response = config_payload()
    response["config_path"] = str(saved_path)
    response["notice"] = restart_daemon_if_managed()
    return response
